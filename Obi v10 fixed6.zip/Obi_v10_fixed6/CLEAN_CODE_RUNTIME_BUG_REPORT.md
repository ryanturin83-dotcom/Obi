# Clean Code + Runtime Bug Pass

Date: 2026-04-28

## Fixed

- Corrected `scripts/runtime_smoke_test.py` to call the real onboarding route: `/api/profile/onboarding`.
- Added a safe authenticated `/api/me` endpoint so frontend and load-test checks have a stable current-user route.
- Added a hard total timeout to the Python runtime smoke test with `SMOKE_TEST_TIMEOUT_SECONDS`.
- Changed runtime test emails to include a UUID suffix to avoid duplicate-user collisions during repeated runs.
- Added shell-level timeouts to runtime, deployment, backup, restore, Mongo shell, and alert checks so scripts fail cleanly instead of hanging.
- Reduced the Redis WebSocket pub/sub loop from a zero-sleep spin to a short sleep to avoid unnecessary CPU churn.
- Added the missing `frontend/scripts/smoke-config.js` used by `npm run test:smoke`.

## Verified in this environment

Passed:

```bash
python -S -m py_compile backend/server.py backend/test_core_flow.py scripts/runtime_smoke_test.py
timeout 5 node --check frontend/App.js
timeout 5 node --check frontend/src/api.js
timeout 5 node --check frontend/scripts/smoke-config.js
cd frontend && timeout 5 node scripts/smoke-config.js
bash -n scripts/run_full_runtime_check.sh scripts/deployment_drill.sh scripts/backup_restore_check.sh
```

Also verified the Python runtime smoke test exits cleanly with a non-zero status when the API is unavailable, instead of hanging.

## Not executed here

Full live runtime testing still requires real services running: MongoDB, Redis, storage credentials, backend dependencies, and a running API server.
