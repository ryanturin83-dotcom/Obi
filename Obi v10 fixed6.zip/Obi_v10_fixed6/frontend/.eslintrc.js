module.exports = {
  root: true,
  extends: '@react-native',
  rules: {
    // Warn on console.log left in, allow console.warn/error
    'no-console': ['warn', { allow: ['warn', 'error'] }],
    // Catch undefined variables (common source of RN runtime crashes)
    'no-undef': 'error',
    // Prevent unused imports bloating the bundle
    'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
  },
  env: {
    browser: false,
    node: true,
    es2021: true,
  },
};
