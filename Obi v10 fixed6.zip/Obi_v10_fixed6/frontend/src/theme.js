export const colors={bg:"#0F0B07",card:"#1C140C",gold:"#C8922A",cream:"#FAF6F0",muted:"#B5A898",danger:"#B42318",text:"#FFFFFF"};
