import AsyncStorage from "@react-native-async-storage/async-storage";

const BASE_URL = process.env.EXPO_PUBLIC_BACKEND_URL || "http://localhost:8001/api";
const WS_URL = BASE_URL.replace(/^http/, "ws").replace(/\/api$/, "/api/ws");

const DEFAULT_TIMEOUT_MS = Number(process.env.EXPO_PUBLIC_API_TIMEOUT_MS || 15000);
const UPLOAD_TIMEOUT_MS = Number(process.env.EXPO_PUBLIC_UPLOAD_TIMEOUT_MS || 45000);

function withTimeout(ms) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), ms);
  return { controller, timeoutId };
}

function friendlyError(error, fallback = "Something went wrong") {
  if (error?.name === "AbortError") {
    return "Request timed out. Check your connection and try again.";
  }
  return error?.message || fallback;
}

async function getToken() {
  return AsyncStorage.getItem("asa_token");
}

async function request(path, options = {}) {
  const token = await getToken();
  const headers = {
    ...(options.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  };

  const timeoutMs = options.timeoutMs || DEFAULT_TIMEOUT_MS;
  const { controller, timeoutId } = withTimeout(timeoutMs);

  try {
    const res = await fetch(`${BASE_URL}${path}`, {
      ...options,
      headers,
      signal: options.signal || controller.signal,
    });
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) throw new Error(data.detail || data.message || "Something went wrong");
    return data;
  } catch (error) {
    throw new Error(friendlyError(error));
  } finally {
    clearTimeout(timeoutId);
  }
}

export const api = {
  baseUrl: BASE_URL,
  wsUrl: WS_URL,
  getToken,
  setToken: (token) => AsyncStorage.setItem("asa_token", token),
  clearToken: () => AsyncStorage.removeItem("asa_token"),
  me: () => request("/auth/me"),
  register: (email, password, name, date_of_birth, accepted_tos) => request("/auth/register", { method: "POST", body: JSON.stringify({ email, password, name, date_of_birth, accepted_tos }) }),
  resendVerification: () => request("/auth/resend-verification", { method: "POST" }),
  verifyEmail: (token) => request("/auth/verify-email", { method: "POST", body: JSON.stringify({ token }) }),
  login: (email, password) => request("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),
  logout: () => request("/auth/logout", { method: "POST" }),
  changePassword: (current_password, new_password) => request("/auth/change-password", { method: "POST", body: JSON.stringify({ current_password, new_password }) }),
  requestAccountDeletion: (email) => request("/auth/request-account-deletion", { method: "POST", body: JSON.stringify({ email }) }),
  confirmAccountDeletion: (token) => request("/auth/confirm-account-deletion", { method: "POST", body: JSON.stringify({ token }) }),
  onboard: (payload) => request("/profile/onboarding", { method: "POST", body: JSON.stringify(payload) }),
  updateFilters: (payload) => request("/profile/filters", { method: "PUT", body: JSON.stringify(payload) }),
  discover: () => request("/discover"),
  compatibility: (candidateId) => request(`/compatibility/${candidateId}`),
  swipe: (target_user_id, action) => request("/swipe", { method: "POST", body: JSON.stringify({ target_user_id, action }) }),
  matches: () => request("/matches"),
  messages: (matchId, { before } = {}) => request(`/messages/${matchId}${before ? `?before=${encodeURIComponent(before)}` : ""}`),
  sendMessage: (match_id, text) => request("/messages", { method: "POST", body: JSON.stringify({ match_id, text }) }),
  likes: () => request("/likes"),
  boost: () => request("/boost", { method: "POST" }),
  heatmap: () => request("/heatmap"),
  translate: (text, target_language, source_language = null) => request("/translate", { method: "POST", body: JSON.stringify({ text, target_language, source_language }) }),
  report: (target_user_id, reason) => request("/report", { method: "POST", body: JSON.stringify({ target_user_id, reason }) }),
  block: (target_user_id) => request("/block", { method: "POST", body: JSON.stringify({ target_user_id }) }),
  checkout: () => request("/stripe/create-checkout-session", { method: "POST" }),
  registerPushToken: (token) => request("/push/register", { method: "POST", body: JSON.stringify({ token }) }),
  getLegal: (docType) => request(`/legal/${docType}`),
  submitComplaint: (complaint_type, description, related_user_id = null, related_content_id = null) =>
    request("/complaints", { method: "POST", body: JSON.stringify({ complaint_type, description, related_user_id, related_content_id }) }),
  getMyComplaints: () => request("/complaints"),
  exportMyData: () => request("/auth/export-my-data"),
  uploadPhoto: async (uri, mimeType = "image/jpeg") => {
    const token = await getToken();
    if (!token) throw new Error("You must be logged in to upload photos.");
    const ext = (mimeType.split("/")[1] || "jpg").replace("jpeg", "jpg");
    const formData = new FormData();
    formData.append("file", { uri, name: `photo.${ext}`, type: mimeType });

    const { controller, timeoutId } = withTimeout(UPLOAD_TIMEOUT_MS);
    try {
      const res = await fetch(`${BASE_URL}/profile/photo`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
        signal: controller.signal,
      });
      let data = {};
      try { data = await res.json(); } catch {}
      if (!res.ok) throw new Error(data.detail || data.message || "Photo upload failed");
      return data;
    } catch (error) {
      throw new Error(friendlyError(error, "Photo upload failed"));
    } finally {
      clearTimeout(timeoutId);
    }
  },
};
