
import React from "react";
import { View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { colors } from "../theme";

export default function ProfileCard({ user }) {
  return (
    <LinearGradient
      colors={["#2A160B", "#17100B"]}
      style={{ borderRadius: 30, padding: 22, minHeight: 390, justifyContent: "flex-end", borderWidth: 1, borderColor: "#3A2A18" }}
    >
      <View style={{ position: "absolute", top: 16, right: 16, backgroundColor: colors.gold, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999 }}>
        <Text style={{ color: "white", fontWeight: "900" }}>{user.compatibility_score || 70}% match</Text>
      </View>

      <Text style={{ color: colors.text, fontSize: 34, fontWeight: "900" }}>{user.name}{user.age ? `, ${user.age}` : ""}</Text>
      <Text style={{ color: colors.muted, fontSize: 16, marginTop: 6 }}>{[user.city, user.country].filter(Boolean).join(" · ") || "Nearby"}</Text>
      {!!user.bio && <Text style={{ color: colors.cream, fontSize: 16, marginTop: 14, lineHeight: 23 }}>{user.bio}</Text>}
      <Text style={{ color: colors.gold, marginTop: 14, fontWeight: "900" }}>{user.compatibility_label || "Potential match"}</Text>
    </LinearGradient>
  );
}
