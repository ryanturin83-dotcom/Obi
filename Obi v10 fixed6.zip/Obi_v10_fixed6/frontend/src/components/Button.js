
import React from "react";
import { Pressable, Text } from "react-native";
import { colors } from "../theme";

export default function Button({ title, onPress, variant = "primary", disabled }) {
  const bg = variant === "danger" ? colors.danger : variant === "ghost" ? "transparent" : colors.gold;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={{
        backgroundColor: disabled ? "#5A5148" : bg,
        borderWidth: variant === "ghost" ? 1 : 0,
        borderColor: colors.gold,
        paddingVertical: 14,
        paddingHorizontal: 18,
        borderRadius: 999,
        alignItems: "center",
        marginVertical: 6,
      }}
    >
      <Text style={{ color: colors.text, fontWeight: "800", fontSize: 16 }}>{title}</Text>
    </Pressable>
  );
}
