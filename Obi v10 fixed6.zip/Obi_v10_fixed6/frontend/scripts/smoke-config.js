const fs = require('fs');
const path = require('path');

function readJson(file) {
  return JSON.parse(fs.readFileSync(path.join(__dirname, '..', file), 'utf8'));
}

const pkg = readJson('package.json');
const app = readJson('app.json');
const eas = readJson('eas.json');

const requiredDeps = [
  'expo',
  'react',
  'react-native',
  '@react-native-async-storage/async-storage',
  'expo-notifications',
  'expo-image-picker',
];
for (const dep of requiredDeps) {
  if (!pkg.dependencies || !pkg.dependencies[dep]) {
    throw new Error(`Missing required dependency: ${dep}`);
  }
}
if (!app.expo || !app.expo.ios || !app.expo.ios.bundleIdentifier) {
  throw new Error('app.json is missing expo.ios.bundleIdentifier');
}
if (!eas.build || !eas.build.production) {
  throw new Error('eas.json is missing build.production');
}
console.log('Frontend config smoke check passed');
