#!/usr/bin/env bash
set -euo pipefail

if ! command -v npx >/dev/null 2>&1; then
  echo "npx is required. Install Node.js first." >&2
  exit 1
fi

cd "$(dirname "$0")/.."

npm install
npx expo-doctor || true
npx eas login
npx eas build:configure
npx eas build --platform ios --profile production

echo "When the build completes successfully, submit it with:"
echo "npx eas submit --platform ios --latest"
