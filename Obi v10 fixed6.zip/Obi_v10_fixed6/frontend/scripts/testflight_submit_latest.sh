#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npx eas submit --platform ios --latest
