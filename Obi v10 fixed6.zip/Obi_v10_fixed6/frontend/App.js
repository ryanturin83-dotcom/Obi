import React, { useEffect, useRef, useState, useCallback } from "react";
import { ActivityIndicator, Alert, BackHandler, FlatList, Image, KeyboardAvoidingView, Linking, Platform, SafeAreaView, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import * as ImagePicker from "expo-image-picker";
import * as Notifications from "expo-notifications";
import Constants from "expo-constants";
import { api } from "./src/api";
import { colors } from "./src/theme";
import Button from "./src/components/Button";
import ProfileCard from "./src/components/ProfileCard";

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: true }),
});

class AppErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, padding: 24, justifyContent: "center" }}>
          <Text style={{ color: colors.gold, fontSize: 34, fontWeight: "900", marginBottom: 10 }}>Àṣà</Text>
          <Text style={{ color: colors.text, fontSize: 22, fontWeight: "900", marginBottom: 8 }}>Something went wrong</Text>
          <Text style={{ color: colors.muted, marginBottom: 18 }}>{this.state.error?.message || "Please restart the app."}</Text>
          <Button title="Try again" onPress={() => this.setState({ error: null })} />
        </SafeAreaView>
      );
    }
    return this.props.children;
  }
}


async function registerForPushNotifications() {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  if (existingStatus !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== "granted") return;
  try {
    // projectId is required for production builds; read it from app config so it
    // stays in sync with eas.json without a code change.
    const projectId =
      Constants.expoConfig?.extra?.eas?.projectId ??
      Constants.easConfig?.projectId;
    if (!projectId) {
      console.warn("Push registration skipped: projectId not set in app.json extra.eas.projectId");
      return;
    }
    const tokenData = await Notifications.getExpoPushTokenAsync({ projectId });
    await api.registerPushToken(tokenData.data);
  } catch (e) {
    console.warn("Push registration failed:", e.message);
  }
}

function Field({ placeholder, value, onChangeText, secureTextEntry, keyboardType = "default", multiline = false }) {
  return (
    <TextInput
      placeholder={placeholder}
      placeholderTextColor={colors.muted}
      value={value}
      onChangeText={onChangeText}
      secureTextEntry={secureTextEntry}
      keyboardType={keyboardType}
      multiline={multiline}
      autoCapitalize="none"
      style={{ backgroundColor: colors.card, color: colors.text, borderRadius: 16, padding: 16, marginVertical: 8, borderWidth: 1, borderColor: "#2A2117", minHeight: multiline ? 96 : undefined, textAlignVertical: multiline ? "top" : "center" }}
    />
  );
}

function SectionTitle({ title, subtitle }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={{ color: colors.text, fontSize: 24, fontWeight: "900" }}>{title}</Text>
      {!!subtitle && <Text style={{ color: colors.muted, marginTop: 4 }}>{subtitle}</Text>}
    </View>
  );
}

function Chip({ text }) {
  if (!text) return null;
  return <Text style={{ color: colors.cream, backgroundColor: "#2A2117", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, marginRight: 6, marginTop: 6 }}>{text}</Text>;
}

function ChoiceChip({ label, selected, onPress }) {
  return (
    <Text
      onPress={onPress}
      style={{
        color: selected ? colors.text : colors.cream,
        backgroundColor: selected ? colors.gold : "#2A2117",
        paddingHorizontal: 14,
        paddingVertical: 10,
        borderRadius: 999,
        marginRight: 8,
        marginBottom: 8,
        overflow: "hidden",
        fontWeight: "800",
      }}
    >
      {label}
    </Text>
  );
}

function StepIndicator({ step, total }) {
  const progress = String(((step + 1) / total) * 100) + "%";
  return (
    <View style={{ marginBottom: 18 }}>
      <Text style={{ color: colors.muted, marginBottom: 8 }}>Step {step + 1} of {total}</Text>
      <View style={{ height: 8, borderRadius: 999, backgroundColor: "#2A2117", overflow: "hidden" }}>
        <View style={{ width: progress, height: "100%", backgroundColor: colors.gold }} />
      </View>
    </View>
  );
}

/** Pulsing placeholder shown while content is loading. */
function SkeletonCard({ lines = 3 }) {
  return (
    <View style={{ backgroundColor: colors.card, borderRadius: 18, padding: 16, marginBottom: 12, opacity: 0.5 }}>
      <View style={{ height: 18, backgroundColor: "#3A2F1A", borderRadius: 6, marginBottom: 10, width: "60%" }} />
      {Array.from({ length: lines - 1 }).map((_, i) => (
        <View key={i} style={{ height: 13, backgroundColor: "#3A2F1A", borderRadius: 6, marginBottom: 8, width: i % 2 === 0 ? "85%" : "70%" }} />
      ))}
    </View>
  );
}

/** Inline error banner — replaces Alert.alert for non-blocking errors. */
function InlineError({ message, onDismiss }) {
  if (!message) return null;
  return (
    <TouchableOpacity
      onPress={onDismiss}
      style={{ backgroundColor: "#4A1A1A", borderRadius: 12, padding: 12, marginBottom: 10, flexDirection: "row", alignItems: "center" }}
      accessibilityRole="alert"
    >
      <Text style={{ color: "#FF8A80", flex: 1, lineHeight: 20 }}>⚠️ {message}</Text>
      <Text style={{ color: colors.muted, marginLeft: 8 }}>✕</Text>
    </TouchableOpacity>
  );
}

/**
 * Renders a legal document (ToS or Privacy) fetched from the API.
 * Avoids opening a browser — keeps the user in-app.
 */
function LegalScreen({ docType, onBack }) {
  const [doc, setDoc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    api.getLegal(docType)
      .then(setDoc)
      .catch(() => setErr("Could not load document. Please try again."))
      .finally(() => setLoading(false));
  }, [docType]);

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
      <TouchableOpacity onPress={onBack} style={{ marginBottom: 16 }}>
        <Text style={{ color: colors.gold, fontSize: 16 }}>← Back</Text>
      </TouchableOpacity>
      {loading && [1,2,3,4].map(i => <SkeletonCard key={i} lines={4} />)}
      {err && <InlineError message={err} onDismiss={() => setErr(null)} />}
      {doc && (
        <>
          <Text style={{ color: colors.text, fontSize: 22, fontWeight: "900", marginBottom: 4 }}>{doc.title}</Text>
          <Text style={{ color: colors.muted, fontSize: 13, marginBottom: 20 }}>
            Effective {doc.effective_date} · Version {doc.version}
            {doc.data_controller ? `\nData controller: ${doc.data_controller}` : ""}
          </Text>
          {(doc.sections || []).map((s, i) => (
            <View key={i} style={{ marginBottom: 18 }}>
              <Text style={{ color: colors.gold, fontWeight: "800", marginBottom: 6 }}>{s.heading}</Text>
              <Text style={{ color: colors.cream, lineHeight: 22 }}>{s.body}</Text>
            </View>
          ))}
          {doc.contact_email && (
            <Text style={{ color: colors.muted, marginTop: 10 }}>
              Questions? <Text style={{ color: colors.gold }} onPress={() => Linking.openURL(`mailto:${doc.contact_email}`)}>{doc.contact_email}</Text>
            </Text>
          )}
        </>
      )}
    </ScrollView>
  );
}

function AsaApp() {
  const [screen, setScreen] = useState("auth");
  const [authMode, setAuthMode] = useState("register");
  const [dob, setDob] = useState("");          // "YYYY-MM-DD" — date of birth for age gate
  const [acceptedTos, setAcceptedTos] = useState(false); // ToS + Privacy Policy checkbox
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [cards, setCards] = useState([]);
  const [cardsLoading, setCardsLoading] = useState(false);
  const [matchesLoading, setMatchesLoading] = useState(false);
  const [matches, setMatches] = useState([]);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState("");
  const [messagesOlderCursor, setMessagesOlderCursor] = useState(null);
  const [messagesAllLoaded, setMessagesAllLoaded] = useState(false);
  const [likesData, setLikesData] = useState(null);
  const [heatmapData, setHeatmapData] = useState([]);
  const [translationInput, setTranslationInput] = useState("");
  const [translationLang, setTranslationLang] = useState("en");
  const [translationResult, setTranslationResult] = useState("");
  const [reportReason, setReportReason] = useState("");
  const [deletionToken, setDeletionToken] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [wsStatus, setWsStatus] = useState("offline");
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [inlineError, setInlineError] = useState("");       // non-modal error banner
  const [legalDoc, setLegalDoc] = useState(null);           // "terms" | "privacy" | null
  const [verifyEmailToken, setVerifyEmailToken] = useState(null);  // token from deep link
  const [verifyEmailBusy, setVerifyEmailBusy] = useState(false);
  const [verifyEmailDone, setVerifyEmailDone] = useState(false);
  const [complaintType, setComplaintType] = useState("other");
  const [complaintText, setComplaintText] = useState("");
  const socketRef = useRef(null);

  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [city, setCity] = useState("");
  const [country, setCountry] = useState("");
  const [tribe, setTribe] = useState("");
  const [bio, setBio] = useState("");
  const [interests, setInterests] = useState("");
  const [languages, setLanguages] = useState("");
  const [maxAge, setMaxAge] = useState("45");
  const [maxDistance, setMaxDistance] = useState("50");
  const [filterGender, setFilterGender] = useState("");
  const [filterCountry, setFilterCountry] = useState("");
  const [filterLanguage, setFilterLanguage] = useState("");

  function hydrateProfile(profile) {
    if (!profile) return;
    setUser(profile);
    setName(profile.name || "");
    setAge(profile.age ? String(profile.age) : "");
    setGender(profile.gender || "");
    setCity(profile.city || "");
    setCountry(profile.country || "");
    setTribe(profile.tribe || "");
    setBio(profile.bio || "");
    setInterests((profile.interests || []).join(", "));
    setLanguages((profile.languages || []).join(", "));
    const f = profile.filters || {};
    setMaxAge(String(f.max_age || 45));
    setMaxDistance(String(f.max_distance || 50));
    setFilterGender(f.gender || "");
    setFilterCountry(f.country || "");
    setFilterLanguage(f.language || "");
  }

  async function refreshMe() {
    const me = await api.me();
    hydrateProfile(me);
    return me;
  }

  // ── Deep-link handler (/verify-email?token=...) ────────────────────────────
  const handleDeepLink = useCallback((url) => {
    if (!url) return;
    try {
      const parsed = new URL(url);
      const token = parsed.searchParams.get("token");
      if ((parsed.pathname === "/verify-email" || parsed.pathname.endsWith("/verify-email")) && token) {
        setVerifyEmailToken(token);
        setVerifyEmailDone(false);
        setScreen("verifyEmail");
      }
    } catch {}
  }, []);

  async function consumeVerifyEmailToken(token) {
    setVerifyEmailBusy(true);
    try {
      await api.verifyEmail(token);
      setVerifyEmailDone(true);
      // Refresh user so email_verified flips to true in state
      try { await refreshMe(); } catch {}
    } catch (e) {
      setInlineError(e.message || "Verification failed. The link may have expired.");
    } finally {
      setVerifyEmailBusy(false);
    }
  }

  // ── Complaints ─────────────────────────────────────────────────────────────
  async function submitComplaint() {
    if (!complaintText.trim() || complaintText.trim().length < 20) {
      setInlineError("Please provide a more detailed description (at least 20 characters).");
      return;
    }
    try {
      setBusy(true);
      const res = await api.submitComplaint(complaintType, complaintText.trim());
      setComplaintText("");
      Alert.alert("Complaint received", `Reference: ${res.reference_id}\n\nWe'll respond within 7 working days.`);
    } catch (e) {
      setInlineError(e.message);
    } finally {
      setBusy(false);
    }
  }

  // ── Data export ────────────────────────────────────────────────────────────
  async function exportMyData() {
    try {
      setBusy(true);
      const res = await api.exportMyData();
      Alert.alert(
        "Data export ready",
        `Your data has been prepared. It contains your profile, ${res.messages_sent?.length ?? 0} messages, and ${res.swipes?.length ?? 0} swipes.\n\nIn production this would be emailed to you or available as a download.`
      );
    } catch (e) {
      setInlineError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleAuth() {
    if (authMode === "register") {
      // Client-side age gate
      if (!dob) { Alert.alert("Date of birth required", "Please enter your date of birth."); return; }
      const parts = dob.trim().split("-");
      if (parts.length !== 3) { Alert.alert("Invalid date", "Please enter your date of birth in YYYY-MM-DD format."); return; }
      const birthDate = new Date(dob.trim());
      if (isNaN(birthDate.getTime())) { Alert.alert("Invalid date", "Please enter a valid date in YYYY-MM-DD format."); return; }
      const today = new Date();
      let ageYears = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) ageYears--;
      if (ageYears < 18) { Alert.alert("Age restriction", "You must be at least 18 years old to use Àṣà."); return; }
      if (!acceptedTos) { Alert.alert("Terms required", "Please accept the Terms of Service and Privacy Policy to continue."); return; }
    }
    try {
      setBusy(true);
      const res = authMode === "login"
        ? await api.login(email, password)
        : await api.register(email, password, name, dob.trim(), acceptedTos);
      await api.setToken(res.token);
      hydrateProfile(res.user);
      if (res.email_verification_required) {
        Alert.alert(
          "Verify your email",
          `A verification link has been sent to ${email}. Please check your inbox before you can start discovering.`
        );
      }
      await registerForPushNotifications();
      setScreen(res.user.onboarded ? "discover" : "onboard");
    } catch (e) {
      Alert.alert("Couldn't continue", e.message);
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    try { await api.logout(); } catch (e) { console.warn("Server logout failed:", e.message); }
    try { socketRef.current?.close(); } catch {}
    await api.clearToken();
    setUser(null); setCards([]); setMatches([]); setMessages([]); setSelectedMatch(null); setScreen("auth"); setWsStatus("offline");
  }

  async function onboard() {
    const parsedAge = Number.parseInt(age, 10);
    const interestList = interests.split(",").map((item) => item.trim()).filter(Boolean);
    const languageList = languages.split(",").map((item) => item.trim()).filter(Boolean);
    if (!parsedAge || parsedAge < 18) return Alert.alert("Age required", "You must be 18 or older to use Àṣà.");
    if (!gender.trim() || !city.trim() || !country.trim()) return Alert.alert("Profile incomplete", "Please add your gender, city, and country.");
    if (interestList.length < 3) return Alert.alert("Add interests", "Choose at least 3 interests, separated by commas.");
    try {
      setBusy(true);
      const res = await api.onboard({ age: parsedAge, gender: gender.trim(), city: city.trim(), country: country.trim(), tribe: tribe.trim() || null, bio: bio.trim() || null, interests: interestList, languages: languageList });
      hydrateProfile(res); setScreen("discover");
    } catch (e) { Alert.alert("Onboarding failed", e.message); } finally { setBusy(false); }
  }

  async function saveFilters() {
    try {
      const payload = { max_age: Number.parseInt(maxAge, 10) || 45, max_distance: Number.parseInt(maxDistance, 10) || 50, gender: filterGender.trim() || null, country: filterCountry.trim() || null, language: filterLanguage.trim() || null };
      const res = await api.updateFilters(payload);
      setUser((prev) => ({ ...(prev || {}), filters: res.filters }));
      Alert.alert("Filters saved", "Your discover feed will use these preferences.");
      setScreen("discover");
    } catch (e) { Alert.alert("Could not save filters", e.message); }
  }

  async function loadDiscover() {
    try {
      setCardsLoading(true);
      setCards(await api.discover());
    } catch (e) {
      setInlineError(e.message || "Could not load profiles.");
    } finally {
      setCardsLoading(false);
    }
  }
  async function swipe(action) {
    const target = cards[0]; if (!target) return;
    try {
      const res = await api.swipe(target.id, action);
      setCards((prev) => prev.slice(1));
      if (res.match) Alert.alert("It's a match 💛", "Open Matches to start chatting.");
    } catch (e) { setInlineError(e.message || "Swipe failed."); }
  }
  async function loadMatches() {
    try {
      setMatchesLoading(true);
      setMatches(await api.matches());
    } catch (e) {
      setInlineError(e.message || "Could not load matches.");
    } finally {
      setMatchesLoading(false);
    }
  }
  async function openChat(match) {
    setSelectedMatch(match);
    setMessages([]);
    setMessagesOlderCursor(null);
    setMessagesAllLoaded(false);
    setScreen("chat");
    try {
      const page = await api.messages(match.id);
      setMessages(page);
      // If the backend returned a full page (50), there may be older messages
      setMessagesOlderCursor(page.length > 0 ? page[0].created_at : null);
      setMessagesAllLoaded(page.length < 50);
    } catch (e) { Alert.alert("Messages failed", e.message); }
  }

  async function loadOlderMessages() {
    if (messagesAllLoaded || !selectedMatch || !messagesOlderCursor) return;
    try {
      const page = await api.messages(selectedMatch.id, { before: messagesOlderCursor });
      if (page.length === 0) { setMessagesAllLoaded(true); return; }
      setMessages((prev) => [...page, ...prev]);
      setMessagesOlderCursor(page[0].created_at);
      if (page.length < 50) setMessagesAllLoaded(true);
    } catch (e) { Alert.alert("Failed to load older messages", e.message); }
  }
  async function sendChatMessage() {
    if (!selectedMatch || !messageText.trim()) return;
    try {
      const msg = await api.sendMessage(selectedMatch.id, messageText.trim());
      setMessages((prev) => [...prev, msg]); setMessageText("");
    } catch (e) { Alert.alert("Send failed", e.message); }
  }

  async function pickAndUploadPhoto() {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) return Alert.alert("Permission needed", "Allow photo access to upload a profile photo.");
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [4, 5], quality: 0.85 });
      if (result.canceled) return;
      const asset = result.assets[0];
      const uploaded = await api.uploadPhoto(asset.uri, asset.mimeType || "image/jpeg");
      setUser((prev) => ({ ...(prev || {}), photo_url: uploaded.photo_url }));
      Alert.alert("Photo uploaded", uploaded.moderation_status === "queued" ? "Your photo is queued for review." : "Your profile photo was updated.");
    } catch (e) { Alert.alert("Photo upload failed", e.message); }
  }

  async function reportCurrentProfile() {
    const target = cards[0]; if (!target) return Alert.alert("No profile", "There is no profile to report right now.");
    if (!reportReason.trim()) return Alert.alert("Reason required", "Please add a short reason first.");
    try { await api.report(target.id, reportReason.trim()); setReportReason(""); Alert.alert("Report sent", "Thanks — our moderation queue will review this."); } catch (e) { Alert.alert("Report failed", e.message); }
  }
  async function blockCurrentProfile() {
    const target = cards[0]; if (!target) return;
    try { await api.block(target.id); setCards((prev) => prev.slice(1)); Alert.alert("Blocked", "You will not see this profile again."); } catch (e) { Alert.alert("Block failed", e.message); }
  }

  async function loadLikes() { try { setLikesData(await api.likes()); } catch (e) { Alert.alert("Likes failed", e.message); } }
  async function boostProfile() { try { await api.boost(); Alert.alert("Boost active", "Your profile is boosted for the next hour."); } catch (e) { Alert.alert("Boost unavailable", e.message); } }
  async function openCheckout() {
    try {
      const res = await api.checkout();
      const url = res.url || res.checkout_url;
      if (url) Linking.openURL(url); else Alert.alert("Checkout", "Checkout session created, but no URL was returned.");
    } catch (e) { Alert.alert("Checkout failed", e.message); }
  }
  async function loadHeatmap() { try { const res = await api.heatmap(); setHeatmapData(res.cities || []); } catch (e) { Alert.alert("Heatmap failed", e.message); } }
  async function translateText() { try { const res = await api.translate(translationInput, translationLang); setTranslationResult(res.translated_text || ""); } catch (e) { Alert.alert("Translation failed", e.message); } }
  async function changePassword() { try { await api.changePassword(currentPassword, newPassword); setCurrentPassword(""); setNewPassword(""); Alert.alert("Password changed", "Please log in again on other devices."); } catch (e) { Alert.alert("Password change failed", e.message); } }
  async function requestDeletion() { try { await api.requestAccountDeletion(email || user?.email || ""); Alert.alert("Deletion requested", "Check your email/logs for the confirmation token in this environment."); } catch (e) { Alert.alert("Deletion request failed", e.message); } }
  async function confirmDeletion() { try { await api.confirmAccountDeletion(deletionToken.trim()); await api.clearToken(); setScreen("auth"); Alert.alert("Account deleted", "Your account has been marked deleted."); } catch (e) { Alert.alert("Deletion failed", e.message); } }

  useEffect(() => {
    // Handle cold-start deep link (app opened from link while closed)
    Linking.getInitialURL().then((url) => { if (url) handleDeepLink(url); });
    // Handle warm deep links (app already open)
    const sub = Linking.addEventListener("url", (event) => handleDeepLink(event.url));

    api.getToken().then(async (token) => {
      if (!token) return;
      try { const me = await refreshMe(); setScreen(me.onboarded ? "discover" : "onboard"); } catch { await api.clearToken(); }
    });

    return () => sub.remove();
  }, [handleDeepLink]);
  useEffect(() => {
    if (screen === "discover") loadDiscover();
    if (screen === "matches") loadMatches();
    if (screen === "likes") loadLikes();
    if (screen === "heatmap") loadHeatmap();
    // Auto-consume token if we land on verifyEmail screen with a token set
    if (screen === "verifyEmail" && verifyEmailToken && !verifyEmailDone && !verifyEmailBusy) {
      consumeVerifyEmailToken(verifyEmailToken);
    }
  }, [screen]);

  // Android hardware back button — mirrors the "Back" buttons already in the UI
  useEffect(() => {
    if (Platform.OS !== "android") return;
    const backMap = {
      menu: "discover",
      profile: "menu",
      filters: "menu",
      likes: "menu",
      premium: "menu",
      safety: "discover",
      translate: "menu",
      heatmap: "menu",
      complaints: "menu",
      legal: "menu",
      settings: "menu",
      chat: "matches",
      matches: "discover",
    };
    const handler = BackHandler.addEventListener("hardwareBackPress", () => {
      const dest = backMap[screen];
      if (dest) { setScreen(dest); return true; } // true = handled, don't exit
      if (screen === "discover") {
        // On the root screen — show an exit confirmation
        Alert.alert("Exit Obi?", "Press back again to exit.", [
          { text: "Cancel", style: "cancel" },
          { text: "Exit", onPress: () => BackHandler.exitApp() },
        ]);
        return true;
      }
      return false; // let the system handle it (exits app)
    });
    return () => handler.remove();
  }, [screen]);
  useEffect(() => {
    if (!user?.id) return undefined;
    let alive = true;
    let ws;
    let retryTimeout;
    let retryDelay = 1000;

    function connect() {
      if (!alive) return;
      api.getToken().then((token) => {
        if (!token || !alive) return;
        ws = new WebSocket(api.wsUrl);
        socketRef.current = ws;

        ws.onopen = () => {
          setWsStatus("online");
          retryDelay = 1000; // reset backoff on successful connect
          ws.send(JSON.stringify({ type: "auth", token }));
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === "message" && selectedMatch?.id === data.message?.match_id) {
              setMessages((prev) => [...prev, data.message]);
            }
          } catch {}
        };

        ws.onerror = () => setWsStatus("error");

        ws.onclose = () => {
          setWsStatus("offline");
          socketRef.current = null;
          if (alive) {
            retryTimeout = setTimeout(() => {
              retryDelay = Math.min(retryDelay * 2, 30000);
              connect();
            }, retryDelay);
          }
        };
      });
    }

    connect();

    return () => {
      alive = false;
      clearTimeout(retryTimeout);
      try { ws?.close(); } catch {}
    };
  }, [user?.id, selectedMatch?.id]);


  const ONBOARDING_TOTAL_STEPS = 8;
  const presetInterests = ["Music", "Travel", "Food", "Gym", "Faith", "Family", "Gaming", "Fashion", "Business", "Art", "Football", "Books"];
  const presetLanguages = ["English", "Yoruba", "Igbo", "Hausa", "Twi", "Swahili", "French", "Arabic", "Portuguese"];

  function csvToList(value) {
    return value.split(",").map((item) => item.trim()).filter(Boolean);
  }

  function toggleCsv(value, setter, item, max = 99) {
    const current = csvToList(value);
    const exists = current.includes(item);
    const next = exists ? current.filter((entry) => entry !== item) : current.length >= max ? current : [...current, item];
    setter(next.join(", "));
  }

  function goNextOnboardingStep() {
    const parsedAge = Number.parseInt(age, 10);
    const interestList = csvToList(interests);
    if (onboardingStep === 1 && (!name.trim() || !parsedAge || parsedAge < 18)) return Alert.alert("Basics required", "Add your name and confirm you are 18 or older.");
    if (onboardingStep === 2 && !gender.trim()) return Alert.alert("Gender required", "Choose or type your gender so compatibility works.");
    if (onboardingStep === 3 && (!city.trim() || !country.trim())) return Alert.alert("Location required", "Add your city and country. You can change this later.");
    if (onboardingStep === 4 && interestList.length < 3) return Alert.alert("Pick interests", "Choose at least 3 interests.");
    if (onboardingStep === 5 && !user?.photo_url) return Alert.alert("Photo required", "Upload at least one profile photo before continuing.");
    if (onboardingStep >= ONBOARDING_TOTAL_STEPS - 1) return onboard();
    setOnboardingStep((step) => Math.min(step + 1, ONBOARDING_TOTAL_STEPS - 1));
  }

  function goBackOnboardingStep() {
    setOnboardingStep((step) => Math.max(step - 1, 0));
  }

  const currentProfile = cards[0];

  // ── In-app legal document overlay ─────────────────────────────────────────
  if (legalDoc) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
        <LegalScreen docType={legalDoc} onBack={() => setLegalDoc(null)} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <StatusBar style="light" />
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
        <View style={{ padding: 20, flex: 1 }}>
          <Text style={{ color: colors.gold, fontSize: 42, fontWeight: "900", marginBottom: 4 }}>Àṣà</Text>
          <Text style={{ color: colors.muted, fontSize: 16, marginBottom: 18 }}>African dating, rooted in culture. {user ? `WS: ${wsStatus}` : ""}</Text>

          {/* Global inline error banner — replaces most Alert.alert calls */}
          <InlineError message={inlineError} onDismiss={() => setInlineError("")} />

          {screen === "verifyEmail" && (
            <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 20 }}>
              {verifyEmailBusy && <ActivityIndicator color={colors.gold} size="large" style={{ marginBottom: 16 }} />}
              {verifyEmailDone ? (
                <>
                  <Text style={{ color: colors.text, fontSize: 24, fontWeight: "900", textAlign: "center", marginBottom: 8 }}>✅ Email verified!</Text>
                  <Text style={{ color: colors.muted, textAlign: "center", marginBottom: 20 }}>You can now access all features.</Text>
                  <Button title="Continue" onPress={async () => {
                    const me = await refreshMe().catch(() => null);
                    setScreen(me?.onboarded ? "discover" : "onboard");
                  }} />
                </>
              ) : !verifyEmailBusy ? (
                <>
                  <Text style={{ color: colors.text, fontSize: 20, fontWeight: "900", textAlign: "center", marginBottom: 8 }}>Verification failed</Text>
                  <Text style={{ color: colors.muted, textAlign: "center", marginBottom: 20 }}>The link may have expired. Request a new one from Settings.</Text>
                  <Button title="Go to login" onPress={() => setScreen("auth")} />
                </>
              ) : null}
            </View>
          )}

          {screen === "auth" && <View>
            {authMode === "register" && <Field placeholder="Name" value={name} onChangeText={setName} />}
            <Field placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" />
            <Field placeholder="Password (8+ characters)" value={password} onChangeText={setPassword} secureTextEntry />
            {authMode === "register" && (
              <View>
                <Field
                  placeholder="Date of birth (YYYY-MM-DD)"
                  value={dob}
                  onChangeText={setDob}
                  keyboardType="numbers-and-punctuation"
                />
                <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 8 }}>
                  You must be 18 or older to use Àṣà.
                </Text>
                <TouchableOpacity
                  onPress={() => setAcceptedTos(!acceptedTos)}
                  style={{ flexDirection: "row", alignItems: "flex-start", marginBottom: 14 }}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: acceptedTos }}
                >
                  <View style={{
                    width: 22, height: 22, borderRadius: 6, borderWidth: 2,
                    borderColor: acceptedTos ? colors.gold : colors.muted,
                    backgroundColor: acceptedTos ? colors.gold : "transparent",
                    marginRight: 10, marginTop: 2, alignItems: "center", justifyContent: "center",
                  }}>
                    {acceptedTos && <Text style={{ color: "#1A1006", fontWeight: "900", fontSize: 14 }}>✓</Text>}
                  </View>
                  <Text style={{ color: colors.muted, flex: 1, lineHeight: 20 }}>
                    {" and I agree to the "}
                    <Text
                      style={{ color: colors.gold, textDecorationLine: "underline" }}
                      onPress={() => setLegalDoc("terms")}
                    >Terms of Service</Text>
                    {" and "}
                    <Text
                      style={{ color: colors.gold, textDecorationLine: "underline" }}
                      onPress={() => setLegalDoc("privacy")}
                    >Privacy Policy</Text>
                    .
                  </Text>
                </TouchableOpacity>
              </View>
            )}
            <Button title={busy ? "Please wait..." : authMode === "register" ? "Create account" : "Log in"} disabled={busy} onPress={handleAuth} />
            <Button title={authMode === "register" ? "Already have an account? Log in" : "New here? Create account"} variant="ghost" onPress={() => { setAuthMode(authMode === "register" ? "login" : "register"); setAcceptedTos(false); setDob(""); }} />
          </View>}

          {screen === "onboard" && <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <StepIndicator step={onboardingStep} total={ONBOARDING_TOTAL_STEPS} />

            {onboardingStep === 0 && <View>
              <SectionTitle title="Find people you actually connect with" subtitle="Àṣà matches culture, values, interests, and location — not just photos." />
              <View style={{ backgroundColor: colors.card, padding: 20, borderRadius: 24, marginBottom: 14 }}>
                <Text style={{ color: colors.text, fontSize: 20, fontWeight: "900" }}>Your setup takes about one minute.</Text>
                <Text style={{ color: colors.muted, marginTop: 8, lineHeight: 21 }}>We only ask for what powers discover, filters, and compatibility. You can edit everything later.</Text>
              </View>
            </View>}

            {onboardingStep === 1 && <View>
              <SectionTitle title="Start with the basics" subtitle="Your first name and age help people know who they are meeting." />
              <Field placeholder="First name" value={name} onChangeText={setName} />
              <Field placeholder="Age" value={age} onChangeText={setAge} keyboardType="number-pad" />
            </View>}

            {onboardingStep === 2 && <View>
              <SectionTitle title="Who are you?" subtitle="Choose what best represents you. You can type your own answer too." />
              <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: 8 }}>
                {["Woman", "Man", "Non-binary"].map((option) => <ChoiceChip key={option} label={option} selected={gender === option} onPress={() => setGender(option)} />)}
              </View>
              <Field placeholder="Gender" value={gender} onChangeText={setGender} />
              <Field placeholder="Tribe / heritage (optional)" value={tribe} onChangeText={setTribe} />
            </View>}

            {onboardingStep === 3 && <View>
              <SectionTitle title="Where are you based?" subtitle="This keeps discover local. If you deny location permission, manual city still works." />
              <Field placeholder="City" value={city} onChangeText={setCity} />
              <Field placeholder="Country" value={country} onChangeText={setCountry} />
            </View>}

            {onboardingStep === 4 && <View>
              <SectionTitle title="Pick 3–5 interests" subtitle="These power compatibility and help matches start conversations." />
              <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: 8 }}>
                {presetInterests.map((option) => <ChoiceChip key={option} label={option} selected={csvToList(interests).includes(option)} onPress={() => toggleCsv(interests, setInterests, option, 5)} />)}
              </View>
              <Field placeholder="Add your own interests, comma separated" value={interests} onChangeText={setInterests} />
            </View>}

            {onboardingStep === 5 && <View>
              <SectionTitle title="Add your best photo" subtitle="Profiles with photos get more likes. Photos are checked before being shown widely." />
              {!!user?.photo_url && <Image source={{ uri: user.photo_url }} style={{ height: 260, borderRadius: 24, marginBottom: 12, backgroundColor: colors.card }} />}
              {!user?.photo_url && <View style={{ height: 220, borderRadius: 24, marginBottom: 12, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", padding: 20 }}><Text style={{ color: colors.muted, textAlign: "center" }}>No profile photo yet</Text></View>}
              <Button title={user?.photo_url ? "Change photo" : "Upload photo"} onPress={pickAndUploadPhoto} />
            </View>}

            {onboardingStep === 6 && <View>
              <SectionTitle title="Languages" subtitle="Optional, but useful for culture and compatibility." />
              <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: 8 }}>
                {presetLanguages.map((option) => <ChoiceChip key={option} label={option} selected={csvToList(languages).includes(option)} onPress={() => toggleCsv(languages, setLanguages, option, 5)} />)}
              </View>
              <Field placeholder="Languages, comma separated" value={languages} onChangeText={setLanguages} />
            </View>}

            {onboardingStep === 7 && <View>
              <SectionTitle title="One short bio" subtitle="Optional, but a good line makes people much more likely to message." />
              <Field placeholder="Tell people something interesting about you" value={bio} onChangeText={setBio} multiline />
              <View style={{ backgroundColor: colors.card, padding: 16, borderRadius: 18, marginTop: 8 }}>
                <Text style={{ color: colors.text, fontWeight: "900", marginBottom: 6 }}>Ready to discover?</Text>
                <Text style={{ color: colors.muted }}>You can update your profile, photos, filters, and settings any time from the menu.</Text>
              </View>
            </View>}

            <Button title={busy ? "Saving..." : onboardingStep === ONBOARDING_TOTAL_STEPS - 1 ? "Start discovering" : "Continue"} disabled={busy} onPress={goNextOnboardingStep} />
            {onboardingStep > 0 && <Button title="Back" variant="ghost" onPress={goBackOnboardingStep} />}
            <Button title="Sign out" variant="ghost" onPress={logout} />
          </ScrollView>}

          {screen === "discover" && <View style={{ flex: 1 }}>
            {currentProfile ? <ProfileCard user={currentProfile} /> : <View style={{ backgroundColor: colors.card, padding: 24, borderRadius: 24 }}><Text style={{ color: colors.text, fontSize: 22, fontWeight: "800" }}>No profiles nearby</Text><Text style={{ color: colors.muted, marginTop: 8 }}>Check back soon or loosen your filters.</Text></View>}
            {!!currentProfile && <View style={{ flexDirection: "row", flexWrap: "wrap", marginVertical: 10 }}>{(currentProfile.interests || []).slice(0, 5).map((i) => <Chip key={i} text={i} />)}</View>}
            <View style={{ flexDirection: "row", marginTop: 10 }}><View style={{ flex: 1, marginRight: 6 }}><Button title="Pass" variant="ghost" onPress={() => swipe("pass")} /></View><View style={{ flex: 1, marginLeft: 6 }}><Button title="Like 💛" onPress={() => swipe("like")} /></View></View>
            <View style={{ flexDirection: "row" }}><View style={{ flex: 1, marginRight: 6 }}><Button title="Report" variant="ghost" onPress={() => setScreen("safety")} /></View><View style={{ flex: 1, marginLeft: 6 }}><Button title="Block" variant="danger" onPress={blockCurrentProfile} /></View></View>
            <Button title="Menu" variant="ghost" onPress={() => setScreen("menu")} />
          </View>}

          {screen === "menu" && <ScrollView><SectionTitle title="Menu" subtitle="All backend features are now exposed from the app." />
            <Button title="Discover" onPress={() => setScreen("discover")} /><Button title="Matches & chat" onPress={() => setScreen("matches")} /><Button title="Profile & photos" onPress={() => setScreen("profile")} /><Button title="Filters" onPress={() => setScreen("filters")} /><Button title="Likes" onPress={() => setScreen("likes")} /><Button title="Premium / Boost" onPress={() => setScreen("premium")} /><Button title="Translate" onPress={() => setScreen("translate")} /><Button title="Heatmap" onPress={() => setScreen("heatmap")} /><Button title="Complaints & appeals" onPress={() => setScreen("complaints")} /><Button title="Privacy & legal" onPress={() => setScreen("legal")} /><Button title="Settings" onPress={() => setScreen("settings")} /><Button title="Sign out" variant="ghost" onPress={logout} />
          </ScrollView>}

          {screen === "matches" && <View style={{ flex: 1 }}>
            <SectionTitle title="Matches" subtitle="Tap a match to chat." />
            {matchesLoading
              ? [1,2,3].map(i => <SkeletonCard key={i} lines={3} />)
              : <FlatList data={matches} keyExtractor={(item) => item.id} ListEmptyComponent={<Text style={{ color: colors.muted }}>No matches yet.</Text>} renderItem={({ item }) => <View style={{ backgroundColor: colors.card, borderRadius: 18, padding: 16, marginBottom: 10 }}><Text style={{ color: colors.text, fontSize: 18, fontWeight: "800" }}>{item.user?.name || "Match"}</Text><Text style={{ color: colors.muted }}>{item.user?.city || "Start chatting"}</Text><Button title="Open chat" onPress={() => openChat(item)} /></View>} />
            }
            <Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </View>}

          {screen === "chat" && <View style={{ flex: 1 }}><SectionTitle title={selectedMatch?.user?.name || "Chat"} subtitle="Messages are moderated for safety." />
            {/* Email verification nudge banner */}
            {user && !user.email_verified && (
              <View style={{ backgroundColor: "#3B2A00", borderRadius: 12, padding: 12, marginBottom: 10, flexDirection: "row", alignItems: "center", flexWrap: "wrap" }}>
                <Text style={{ color: colors.gold, fontWeight: "700", marginRight: 6 }}>⚠️ Email not verified.</Text>
                <Text style={{ color: colors.muted, flex: 1 }}>Some features are limited. </Text>
                <Text style={{ color: colors.gold, textDecorationLine: "underline" }} onPress={async () => { try { await api.resendVerification(); Alert.alert("Sent", "Verification email resent — check your inbox."); } catch (e) { Alert.alert("Error", e.message); } }}>Resend link</Text>
              </View>
            )}
            {!messagesAllLoaded && messagesOlderCursor && (
              <Button title="Load older messages" onPress={loadOlderMessages} />
            )}
            <FlatList data={messages} keyExtractor={(item) => item.id} renderItem={({ item }) => (
              <View style={{ alignSelf: item.sender_id === user?.id ? "flex-end" : "flex-start", maxWidth: "82%", backgroundColor: item.sender_id === user?.id ? colors.gold : colors.card, padding: 12, borderRadius: 16, marginVertical: 4 }}>
                <Text style={{ color: colors.text }}>{item.text}</Text>
                {/* Translate button on received messages */}
                {item.sender_id !== user?.id && (
                  <TouchableOpacity
                    onPress={async () => {
                      try {
                        const res = await api.translate(item.text, "en");
                        Alert.alert("Translation", res.translated_text || item.text);
                      } catch (e) {
                        Alert.alert("Translation failed", e.message);
                      }
                    }}
                    style={{ marginTop: 4 }}
                  >
                    <Text style={{ color: colors.muted, fontSize: 12 }}>🌐 Translate</Text>
                  </TouchableOpacity>
                )}
              </View>
            )} />
            <Field placeholder="Write a message" value={messageText} onChangeText={setMessageText} /><Button title="Send" onPress={sendChatMessage} /><Button title="Back to matches" variant="ghost" onPress={() => setScreen("matches")} />
          </View>}

          {screen === "profile" && <ScrollView><SectionTitle title="Profile & photos" subtitle="Edit your profile and upload a moderated photo." />
            {!!user?.photo_url && <Image source={{ uri: user.photo_url }} style={{ height: 260, borderRadius: 24, marginBottom: 12, backgroundColor: colors.card }} />}
            <Button title="Upload profile photo" onPress={pickAndUploadPhoto} />
            <Field placeholder="Age" value={age} onChangeText={setAge} keyboardType="number-pad" /><Field placeholder="Gender" value={gender} onChangeText={setGender} /><Field placeholder="City" value={city} onChangeText={setCity} /><Field placeholder="Country" value={country} onChangeText={setCountry} /><Field placeholder="Tribe / heritage" value={tribe} onChangeText={setTribe} /><Field placeholder="Interests" value={interests} onChangeText={setInterests} /><Field placeholder="Languages" value={languages} onChangeText={setLanguages} /><Field placeholder="Bio" value={bio} onChangeText={setBio} multiline />
            <Button title="Save profile" onPress={onboard} /><Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "filters" && <ScrollView><SectionTitle title="Filters" subtitle="Control who appears in discover." />
            <Field placeholder="Max age" value={maxAge} onChangeText={setMaxAge} keyboardType="number-pad" /><Field placeholder="Max distance" value={maxDistance} onChangeText={setMaxDistance} keyboardType="number-pad" /><Field placeholder="Gender preference" value={filterGender} onChangeText={setFilterGender} /><Field placeholder="Country" value={filterCountry} onChangeText={setFilterCountry} /><Field placeholder="Language" value={filterLanguage} onChangeText={setFilterLanguage} />
            <Button title="Save filters" onPress={saveFilters} /><Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "likes" && <ScrollView><SectionTitle title="Likes" subtitle="See who liked you. Full details require Gold." />
            {likesData?.blurred ? <Text style={{ color: colors.text, fontSize: 18 }}>{likesData.count || 0} people liked you. Upgrade to reveal them.</Text> : (likesData?.users || []).map((u) => <View key={u.id} style={{ backgroundColor: colors.card, padding: 14, borderRadius: 14, marginBottom: 8 }}><Text style={{ color: colors.text, fontWeight: "800" }}>{u.name}{u.age ? `, ${u.age}` : ""}</Text><Text style={{ color: colors.muted }}>{u.city}</Text></View>)}
            <Button title="Upgrade to Gold →" onPress={() => setScreen("premium")} /><Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "premium" && <ScrollView>
            <SectionTitle title="Gold & Boost" subtitle="Unlock likes, compatibility reasons, and boosts." />
            <View style={{ backgroundColor: colors.card, borderRadius: 16, padding: 20, marginBottom: 16 }}>
              <Text style={{ color: colors.gold, fontWeight: "800", fontSize: 18, marginBottom: 8 }}>Obi Gold</Text>
              <Text style={{ color: colors.muted, marginBottom: 4 }}>{"•"} See everyone who liked you</Text>
              <Text style={{ color: colors.muted, marginBottom: 4 }}>{"•"} Compatibility reasons for every match</Text>
              <Text style={{ color: colors.muted, marginBottom: 4 }}>{"•"} Unlimited likes</Text>
              <Text style={{ color: colors.muted, marginBottom: 16 }}>{"•"} Priority in discover</Text>
              <Text style={{ color: colors.cream, fontWeight: "700", fontSize: 15, marginBottom: 8 }}>Premium subscriptions coming soon.</Text>
              <Text style={{ color: colors.muted, fontSize: 13 }}>We{"'"}re building a secure in-app payment experience. You{"'"}ll be notified when it{"'"}s available.</Text>
            </View>
            <Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "safety" && <ScrollView><SectionTitle title="Report / block" subtitle={currentProfile ? `Safety actions for ${currentProfile.name}` : "No profile selected."} />
            <Field placeholder="Why are you reporting this profile?" value={reportReason} onChangeText={setReportReason} multiline /><Button title="Submit report" onPress={reportCurrentProfile} /><Button title="Block profile" variant="danger" onPress={blockCurrentProfile} /><Button title="Back" variant="ghost" onPress={() => setScreen("discover")} />
          </ScrollView>}

          {screen === "translate" && <ScrollView><SectionTitle title="Translate" subtitle="Fallback returns original text unless a provider is enabled." />
            <Field placeholder="Text to translate" value={translationInput} onChangeText={setTranslationInput} multiline /><Field placeholder="Target language, e.g. en, fr, yo" value={translationLang} onChangeText={setTranslationLang} /><Button title="Translate" onPress={translateText} />{!!translationResult && <Text style={{ color: colors.cream, backgroundColor: colors.card, padding: 16, borderRadius: 16 }}>{translationResult}</Text>}<Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "heatmap" && <View style={{ flex: 1 }}><SectionTitle title="Community heatmap" subtitle="Cities with onboarded users." />
            <FlatList data={heatmapData} keyExtractor={(item) => item.city} ListEmptyComponent={<Text style={{ color: colors.muted }}>No city data yet.</Text>} renderItem={({ item }) => <View style={{ backgroundColor: colors.card, padding: 14, borderRadius: 14, marginBottom: 8 }}><Text style={{ color: colors.text, fontWeight: "800" }}>{item.city}</Text><Text style={{ color: colors.muted }}>{item.total} users</Text></View>} />
            <Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </View>}

          {screen === "complaints" && <ScrollView>
            <SectionTitle title="Complaints & appeals" subtitle="UK Online Safety Act — all complaints are reviewed within 7 working days." />
            <Text style={{ color: colors.muted, marginBottom: 10 }}>Complaint type:</Text>
            {["moderation_decision", "harmful_content", "account_suspension", "data_handling", "other"].map(t => (
              <TouchableOpacity key={t} onPress={() => setComplaintType(t)} style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
                <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: complaintType === t ? colors.gold : colors.muted, backgroundColor: complaintType === t ? colors.gold : "transparent", marginRight: 10 }} />
                <Text style={{ color: colors.text }}>{t.replace(/_/g, " ")}</Text>
              </TouchableOpacity>
            ))}
            <Field placeholder="Describe your complaint (min. 20 characters)" value={complaintText} onChangeText={setComplaintText} multiline />
            <Button title={busy ? "Submitting…" : "Submit complaint"} disabled={busy} onPress={submitComplaint} />
            <Text style={{ color: colors.muted, fontSize: 12, marginTop: 8, lineHeight: 18 }}>
              If you are not satisfied with our response, you may escalate to Ofcom (ofcom.org.uk).
            </Text>
            <Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "legal" && <ScrollView>
            <SectionTitle title="Privacy & legal" subtitle="Your rights and our policies." />
            <Button title="Terms of Service" onPress={() => setLegalDoc("terms")} />
            <Button title="Privacy Policy" onPress={() => setLegalDoc("privacy")} />
            <Button title="Export my data (GDPR)" onPress={exportMyData} />
            <Text style={{ color: colors.muted, fontSize: 12, marginTop: 12, lineHeight: 18 }}>
              Under UK GDPR you have the right to access, correct, and erase your data.{"\n"}
              Contact: privacy@REPLACE_WITH_YOUR_DOMAIN · ICO: ico.org.uk
            </Text>
            <Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}

          {screen === "settings" && <ScrollView><SectionTitle title="Settings" subtitle="Security, account deletion, and sign out." />
            <Field placeholder="Current password" value={currentPassword} onChangeText={setCurrentPassword} secureTextEntry /><Field placeholder="New password" value={newPassword} onChangeText={setNewPassword} secureTextEntry /><Button title="Change password" onPress={changePassword} />
            <Button title="Request account deletion" variant="danger" onPress={requestDeletion} /><Field placeholder="Deletion confirmation token" value={deletionToken} onChangeText={setDeletionToken} /><Button title="Confirm account deletion" variant="danger" onPress={confirmDeletion} />
            <Button title="Sign out" variant="ghost" onPress={logout} /><Button title="Back" variant="ghost" onPress={() => setScreen("menu")} />
          </ScrollView>}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <AppErrorBoundary>
      <AsaApp />
    </AppErrorBoundary>
  );
}
