# Final validation fixes 1–4

This package now includes concrete assets for the four remaining production validation items.

## 1. Full runtime test

Added:

- `scripts/runtime_smoke_test.py`
- `scripts/run_full_runtime_check.sh`
- `docs/RUNTIME_TEST_PLAN.md`

Covers health, register, login, onboarding, report, logout, and token revocation against a real backend.

## 2. iOS build and TestFlight path

Added:

- `frontend/scripts/testflight_build.sh`
- `frontend/scripts/testflight_submit_latest.sh`
- `docs/IOS_TESTFLIGHT_RUNBOOK.md`

These automate the EAS build/submit path while still requiring Apple/EAS credentials.

## 3. App Store privacy/moderation polish

Added:

- `docs/APP_STORE_PRIVACY_AND_MODERATION.md`

This maps collected data, UGC safety requirements, required public documents, and moderation operations.

## 4. Load, backup, restore, security drills

Added:

- `scripts/deployment_drill.sh`
- Existing `scripts/load_test_k6.js`
- Existing `scripts/backup_restore_check.sh`
- Existing `docs/PRODUCTION_SECURITY_REVIEW.md`

The deployment drill ties health, runtime smoke testing, backup/restore verification, and alert webhook checks together.

## Local static verification performed in this environment

- JSON config parsed successfully for `frontend/package.json`, `frontend/app.json`, and `frontend/eas.json`.
- Shell helper scripts pass `bash -n` syntax checks.
- Python runtime smoke script passes `py_compile`.

Full live validation still requires your actual MongoDB, Redis, backend runtime, Expo/EAS account, Apple Developer account, and deployed API URL.

## Verification update

Because the default virtualenv Python in this sandbox hung on startup, Python syntax verification was run with `/usr/bin/python3` instead.
