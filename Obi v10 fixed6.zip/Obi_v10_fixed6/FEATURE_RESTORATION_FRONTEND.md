# Feature restoration frontend pass

This pass restores access to the backend features that existed but were not exposed in the mobile UI.

## Added / restored in `frontend/App.js`

- Persistent session bootstrap via `/api/auth/me`.
- Main menu screen that links to the restored app areas.
- Chat UI for matches, including message history and sending messages.
- WebSocket connection with first-message token authentication.
- Profile editing screen using the onboarding/profile endpoint.
- Profile photo upload using `expo-image-picker` and `/api/profile/photo`.
- Discover safety flow with report and block actions.
- Filters screen wired to `/api/profile/filters`.
- Likes screen wired to `/api/likes`.
- Premium/Gold checkout screen wired to Stripe checkout endpoint.
- Boost button wired to `/api/boost`.
- Translation screen wired to `/api/translate`.
- Community heatmap screen wired to `/api/heatmap`.
- Settings screen with password change, account deletion request, confirmation, and logout.

## Added / restored in `frontend/src/api.js`

- `me`
- `changePassword`
- `requestAccountDeletion`
- `confirmAccountDeletion`
- `updateFilters`
- `compatibility`
- `boost`
- `translate`
- `report`
- `block`
- `wsUrl`
- safer multipart upload handling without forcing JSON content-type

## Validation performed in this environment

- Python syntax parsed for runtime smoke scripts.
- Frontend JSON configs parsed successfully.
- Shell scripts passed `bash -n`.
- `frontend/src/api.js` passed `node --check`.
- JSX app was manually balanced for brackets/parentheses/braces because this environment does not include installed Expo/Babel dependencies to run a full React Native compile.

## Runtime validation still required on your machine

Run these after installing dependencies and setting `EXPO_PUBLIC_BACKEND_URL`:

```bash
cd frontend
npm install
npx expo start --tunnel
```

Then test these flows in Expo Go/TestFlight:

1. Register/login.
2. Complete onboarding.
3. Upload a profile photo.
4. Save filters.
5. Discover, like/pass, report, block.
6. Open matches and send a message.
7. View likes, premium, boost, translate, heatmap.
8. Change password and logout.
