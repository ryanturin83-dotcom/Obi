#!/usr/bin/env python3
"""End-to-end runtime smoke test for deployed/local Àṣà API.

Usage:
  API_URL=http://localhost:8000 python scripts/runtime_smoke_test.py

Requires the backend to be running with MongoDB and Redis configured. The script
creates disposable test users, exercises auth, onboarding, reporting, health, and
logout/token revocation. It exits non-zero on failures.
"""
import json
import os
import sys
import time
import signal
import uuid
import urllib.error
import urllib.parse
import urllib.request

API_URL = os.getenv("API_URL", "http://localhost:8000").rstrip("/")
RUN_ID = f"{int(time.time())}-{uuid.uuid4().hex[:8]}"
EMAIL_A = f"runtime-a-{RUN_ID}@example.test"
EMAIL_B = f"runtime-b-{RUN_ID}@example.test"
PASSWORD = "RuntimeTest123!"


def request(method, path, token=None, data=None, files=None, expected=(200,)):
    url = API_URL + path
    body = None
    headers = {"Accept": "application/json"}
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            raw = res.read().decode("utf-8")
            payload = json.loads(raw) if raw else {}
            if res.status not in expected:
                raise AssertionError(f"{method} {path}: expected {expected}, got {res.status}: {payload}")
            return payload, res.status
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace")
        payload = json.loads(raw) if raw else {"error": raw}
        if exc.code in expected:
            return payload, exc.code
        raise AssertionError(f"{method} {path}: expected {expected}, got {exc.code}: {payload}") from exc


def _abort_after_timeout(signum, frame):
    raise TimeoutError("runtime smoke test exceeded its safety timeout")


def main():
    signal.signal(signal.SIGALRM, _abort_after_timeout)
    signal.alarm(int(os.getenv("SMOKE_TEST_TIMEOUT_SECONDS", "120")))
    print(f"Runtime smoke test target: {API_URL}")
    health, _ = request("GET", "/api/health")
    assert health.get("api") == "ok", health
    assert health.get("mongo") == "ok", f"Mongo is not healthy: {health}"
    print("✓ health")

    a, _ = request("POST", "/api/auth/register", data={"email": EMAIL_A, "password": PASSWORD, "name": "Runtime A", "date_of_birth": "1995-01-01", "accepted_tos": true})
    b, _ = request("POST", "/api/auth/register", data={"email": EMAIL_B, "password": PASSWORD, "name": "Runtime B", "date_of_birth": "1994-01-01", "accepted_tos": true})
    token_a = a.get("token") or a.get("access_token")
    token_b = b.get("token") or b.get("access_token")
    assert token_a and token_b, "register did not return tokens"
    user_b = b.get("user", {})
    target_user_id = user_b.get("id") or user_b.get("user_id")
    assert target_user_id, f"could not determine user id from {b}"
    print("✓ register")

    login, _ = request("POST", "/api/auth/login", data={"email": EMAIL_A, "password": PASSWORD})
    token_a = login.get("token") or login.get("access_token")
    assert token_a, "login did not return token"
    print("✓ login")

    onboarding_payload = {
        "age": 29,
        "gender": "woman",
        "city": "London",
        "country": "GB",
        "tribe": "Yoruba",
        "bio": "Runtime smoke test profile",
        "occupation": "Tester",
        "interests": ["music", "culture", "food"],
        "languages": ["English", "Yoruba"],
        "latitude": 51.5072,
        "longitude": -0.1276,
    }
    request("POST", "/api/profile/onboarding", token=token_a, data=onboarding_payload)
    print("✓ onboarding")

    request("POST", "/api/report", token=token_a, data={"target_user_id": target_user_id, "reason": "runtime smoke test"})
    print("✓ report")

    request("POST", "/api/auth/logout", token=token_a, data={})
    _, status = request("GET", "/api/discover", token=token_a, expected=(401, 403))
    print(f"✓ logout revokes token ({status})")

    signal.alarm(0)
    print("Runtime smoke test passed")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Runtime smoke test failed: {exc}", file=sys.stderr)
        sys.exit(1)
