#!/usr/bin/env bash
set -euo pipefail

: "${MONGO_URL:?Set MONGO_URL before running backup/restore check}"
DB_NAME="${DB_NAME:-asa_dating}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
RESTORE_DB="${MONGORESTORE_DRY_RUN_DB:-asa_restore_drill}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$BACKUP_DIR/$DB_NAME-$STAMP"

mkdir -p "$BACKUP_DIR"
echo "Creating mongodump: $OUT"
timeout "${BACKUP_TIMEOUT_SECONDS:-300}" mongodump --uri="$MONGO_URL" --db="$DB_NAME" --out="$OUT"

echo "Restoring into drill database: $RESTORE_DB"
timeout "${RESTORE_TIMEOUT_SECONDS:-300}" mongorestore --uri="$MONGO_URL" --nsFrom="$DB_NAME.*" --nsTo="$RESTORE_DB.*" "$OUT/$DB_NAME" --drop

echo "Counting restored collections"
timeout "${MONGOSH_TIMEOUT_SECONDS:-60}" mongosh "$MONGO_URL" --quiet --eval "db.getSiblingDB('$RESTORE_DB').getCollectionNames().forEach(c => print(c + ':' + db.getSiblingDB('$RESTORE_DB').getCollection(c).countDocuments()))"

echo "Backup/restore drill completed. Manually verify counts before deleting $RESTORE_DB."
