#!/usr/bin/env bash
set -euo pipefail

: "${API_URL:=https://api.example.com}"
: "${ALERT_WEBHOOK_URL:=}"
: "${RUN_LOAD_TEST:=false}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Deployment drill target: ${API_URL}"

echo "1. Health check"
curl --max-time 15 -fsS "${API_URL%/}/api/health" | tee /tmp/obi-health.json

echo "2. Runtime smoke test"
API_URL="${API_URL}" PYTHONNOUSERSITE=1 timeout "${SMOKE_TEST_TIMEOUT_SECONDS:-120}" python3 "${SCRIPT_DIR}/runtime_smoke_test.py"

echo "3. Admin moderation/metrics smoke test"
API_URL="${API_URL}" PYTHONNOUSERSITE=1 timeout "${ADMIN_SMOKE_TIMEOUT_SECONDS:-60}" python3 "${SCRIPT_DIR}/moderation_admin_smoke_test.py"

echo "4. Backup/restore drill"
"${SCRIPT_DIR}/backup_restore_check.sh"

echo "5. Optional load test"
if [ "${RUN_LOAD_TEST}" = "true" ]; then
  if command -v k6 >/dev/null 2>&1; then
    API_URL="${API_URL}" k6 run "${SCRIPT_DIR}/load_test_k6.js"
  else
    echo "k6 is not installed; install k6 or set RUN_LOAD_TEST=false"
    exit 1
  fi
else
  echo "RUN_LOAD_TEST=false; skipped load test"
fi

echo "6. Alert webhook check"
if [ -n "${ALERT_WEBHOOK_URL}" ]; then
  curl --max-time 15 -fsS -X POST "${ALERT_WEBHOOK_URL}" \
    -H 'Content-Type: application/json' \
    -d '{"text":"Obi deployment drill alert test"}' >/dev/null
  echo "Alert webhook accepted test payload"
else
  echo "ALERT_WEBHOOK_URL is not set; skipped webhook ping"
fi

echo "Deployment drill complete"
