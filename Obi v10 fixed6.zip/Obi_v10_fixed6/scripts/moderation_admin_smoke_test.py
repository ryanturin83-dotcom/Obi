#!/usr/bin/env python3
"""Admin moderation smoke test for a deployed/local Obi API.

Requires:
  API_URL=http://localhost:8000
  ADMIN_API_KEY=<your admin key>

It verifies that protected admin moderation/metrics endpoints are reachable and
that unauthenticated access is rejected. It does not resolve real jobs unless
MODERATION_TEST_RESOLVE_JOB_ID is explicitly provided.
"""
import json
import os
import sys
import urllib.error
import urllib.request

API_URL = os.getenv("API_URL", "http://localhost:8000").rstrip("/")
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "")
TIMEOUT = int(os.getenv("ADMIN_SMOKE_TIMEOUT_SECONDS", "15"))


def request(method, path, admin=False, data=None, expected=(200,)):
    headers = {"Accept": "application/json"}
    if admin:
        headers["x-admin-key"] = ADMIN_API_KEY
    body = None
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(API_URL + path, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as res:
            payload = json.loads(res.read().decode("utf-8") or "{}")
            if res.status not in expected:
                raise AssertionError(f"{method} {path}: expected {expected}, got {res.status}: {payload}")
            return payload, res.status
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace")
        payload = json.loads(raw) if raw else {"error": raw}
        if exc.code in expected:
            return payload, exc.code
        raise AssertionError(f"{method} {path}: expected {expected}, got {exc.code}: {payload}") from exc


def main():
    if not ADMIN_API_KEY:
        print("ADMIN_API_KEY is not set; skipping admin moderation smoke test")
        return 0

    print(f"Admin moderation smoke target: {API_URL}")
    _, status = request("GET", "/api/admin/metrics", expected=(401, 403))
    print(f"✓ unauthenticated admin metrics rejected ({status})")

    metrics, _ = request("GET", "/api/admin/metrics", admin=True)
    assert "moderation_queue" in metrics, metrics
    print("✓ admin metrics")

    jobs, _ = request("GET", "/api/admin/moderation/jobs", admin=True)
    assert isinstance(jobs, list), jobs
    print(f"✓ moderation jobs list ({len(jobs)} returned)")

    job_id = os.getenv("MODERATION_TEST_RESOLVE_JOB_ID")
    if job_id:
        result, _ = request(
            "POST",
            f"/api/admin/moderation/jobs/{job_id}/resolve",
            admin=True,
            data={"action": "approve"},
        )
        assert result.get("resolved") is True, result
        print(f"✓ resolved test moderation job {job_id}")
    else:
        print("✓ resolve step skipped; set MODERATION_TEST_RESOLVE_JOB_ID to test resolution")

    print("Admin moderation smoke test passed")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"Admin moderation smoke test failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
