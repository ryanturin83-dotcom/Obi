import http from 'k6/http';
import ws from 'k6/ws';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '1m', target: 25 },
    { duration: '3m', target: 100 },
    { duration: '1m', target: 0 },
  ],
  thresholds: {
    http_req_failed: ['rate<0.02'],
    http_req_duration: ['p(95)<750'],
    checks: ['rate>0.95'],
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8000';
const TOKEN = __ENV.TEST_JWT || '';

export default function () {
  const headers = TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {};
  const health = http.get(`${BASE_URL}/api/health`);
  check(health, { 'health 200': (r) => r.status === 200 });

  if (TOKEN) {
    const me = http.get(`${BASE_URL}/api/me`, { headers });
    check(me, { 'me not 5xx': (r) => r.status < 500 });

    const wsUrl = BASE_URL.replace(/^http/, 'ws') + '/api/ws';
    ws.connect(wsUrl, {}, (socket) => {
      socket.on('open', () => socket.send(JSON.stringify({ type: 'auth', token: TOKEN })));
      socket.on('message', () => {});
      socket.setTimeout(() => socket.close(), 1000);
    });
  }
  sleep(1);
}
