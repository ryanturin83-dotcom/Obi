#!/usr/bin/env bash
set -euo pipefail
: "${API_URL:=http://localhost:8000}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Running full runtime checks against ${API_URL}"
PYTHONNOUSERSITE=1 timeout "${SMOKE_TEST_TIMEOUT_SECONDS:-120}" python3 "${SCRIPT_DIR}/runtime_smoke_test.py"
PYTHONNOUSERSITE=1 timeout "${ADMIN_SMOKE_TIMEOUT_SECONDS:-60}" python3 "${SCRIPT_DIR}/moderation_admin_smoke_test.py"
echo "Runtime checks complete"
