Backend source included. Run `python -m py_compile backend/server.py` after installing dependencies.
