#!/usr/bin/env python3
"""
Obi v10 — Core flow integration test.

Usage:
    python test_core_flow.py [BASE_URL]

Requires a running backend with MongoDB + Redis. Each run creates unique
users so repeated runs never hit duplicate-email errors.
"""
import sys
import time
import uuid
import requests

BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://localhost:8001"
TIMEOUT = 20

# ── Helpers ──────────────────────────────────────────────────────────────────

def post(path, payload=None, token=None, expect_status=None):
    h = {"Content-Type": "application/json"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    r = requests.post(BASE + path, json=payload or {}, headers=h, timeout=TIMEOUT)
    data = r.json()
    if expect_status is not None:
        assert r.status_code == expect_status, \
            f"{path} expected {expect_status}, got {r.status_code}: {data}"
    elif r.status_code >= 400:
        raise AssertionError(f"{path} {r.status_code}: {data}")
    return data, r.status_code

def get(path, token=None, expect_status=None, params=None):
    h = {}
    if token:
        h["Authorization"] = f"Bearer {token}"
    r = requests.get(BASE + path, headers=h, timeout=TIMEOUT, params=params)
    data = r.json()
    if expect_status is not None:
        assert r.status_code == expect_status, \
            f"{path} expected {expect_status}, got {r.status_code}: {data}"
    elif r.status_code >= 400:
        raise AssertionError(f"{path} {r.status_code}: {data}")
    return data, r.status_code

def ok(label):
    print(f"  ✅ {label}")

def section(label):
    print(f"\n── {label} ──")

# ── Unique per-run suffix ─────────────────────────────────────────────────────
stamp = int(time.time())
uid = uuid.uuid4().hex[:6]

def email(name):
    return f"{name}_{stamp}_{uid}@asa.app"

# ── 1. Health check ───────────────────────────────────────────────────────────
section("Health")
health, _ = get("/api/health")
assert health.get("status") == "ok", f"Health check failed: {health}"
assert health.get("mongo") == "ok", f"Mongo not healthy: {health}"
ok(f"Server healthy — mongo={health['mongo']} redis={health['redis']}")

# ── 2. Registration ───────────────────────────────────────────────────────────
section("Registration")

a, _ = post("/api/auth/register", {
    "email": email("amara"), "password": "password123", "name": "Amara",
    "date_of_birth": "1996-01-15", "accepted_tos": True,
})
b, _ = post("/api/auth/register", {
    "email": email("kwame"), "password": "password123", "name": "Kwame",
    "date_of_birth": "1993-06-20", "accepted_tos": True,
})
ta, tb = a["token"], b["token"]
ok("Two users registered")

# Duplicate email rejected
post("/api/auth/register", {
    "email": email("amara"), "password": "password123", "name": "Amara",
    "date_of_birth": "1996-01-15", "accepted_tos": True,
}, expect_status=400)
ok("Duplicate email rejected")

# Underage user rejected
post("/api/auth/register", {
    "email": email("teen"), "password": "password123", "name": "Teen",
    "date_of_birth": "2015-01-01", "accepted_tos": True,
}, expect_status=400)
ok("Underage registration rejected")

# ToS required
post("/api/auth/register", {
    "email": email("notos"), "password": "password123", "name": "NoTos",
    "date_of_birth": "1995-05-05", "accepted_tos": False,
}, expect_status=422)
ok("Registration without ToS acceptance rejected")

# ── 3. /api/me — authenticated identity ──────────────────────────────────────
section("Authenticated identity (/api/me)")
me_a, _ = get("/api/me", token=ta)
assert me_a["id"] == a["user"]["id"], "me.id mismatch"
assert "password_hash" not in me_a, "password_hash must not leak"
ok("/api/me returns correct safe profile, no private fields")

# ── 4. Email verification + onboarding gates ──────────────────────────────────
section("Email verification + onboarding gates")
# Unverified user blocked from discover
get("/api/discover", token=ta, expect_status=403)
ok("Unverified user blocked from /api/discover")
# Unverified user blocked from swipe
post("/api/swipe", {"target_user_id": b["user"]["id"], "action": "like"}, token=ta, expect_status=403)
ok("Unverified user blocked from /api/swipe")

# Simulate email verification by patching directly (test env bypass)
# In production, the user clicks the link in their email.
# We test the full verify-email endpoint with the token stored in DB.
# For this smoke test we confirm the 403 gate works — full verify flow
# requires a real email delivery service which may not be running.
ok("Email verification gate confirmed (live verify requires email service)")

# ── 5. Onboarding ─────────────────────────────────────────────────────────────
section("Onboarding")
# To test discover/swipe we need verified+onboarded users.
# The test_core_flow script can bypass verification by hitting the DB directly
# if a BYPASS_EMAIL_VERIFY env var is set, or by using a seeded test account.
# For now confirm the gate and onboarding validation work.

# Fewer than 3 interests rejected
post("/api/profile/onboarding", {
    "age": 25, "gender": "Woman", "city": "Lagos", "country": "Nigeria",
    "interests": ["food"], "languages": ["English"],
}, token=ta, expect_status=400)
ok("Onboarding rejects fewer than 3 interests")

# Missing gender rejected
post("/api/profile/onboarding", {
    "age": 25, "gender": "", "city": "Lagos", "country": "Nigeria",
    "interests": ["food", "music", "travel"], "languages": ["English"],
}, token=ta, expect_status=400)
ok("Onboarding rejects missing gender")

# ── NOTE: The following sections require verified+onboarded accounts. ─────────
# Run with FULL_FLOW=1 python test_core_flow.py if the server has email
# verification disabled (EMAIL_VERIFY_REQUIRED=false) or you seed accounts.
import os
if not os.getenv("FULL_FLOW"):
    print("\n⚠️  Skipping discover/swipe/match/message tests.")
    print("   Set FULL_FLOW=1 and run against a server with EMAIL_VERIFY_REQUIRED=false")
    print("   (or seed pre-verified test accounts) to run the complete suite.\n")
    print("✅ Gate + validation tests passed\n")
    sys.exit(0)

# ── 6. Onboarding (full flow) ─────────────────────────────────────────────────
section("Onboarding (full flow)")
post("/api/profile/onboarding", {
    "age": 28, "gender": "Woman", "city": "London", "country": "Ghana",
    "bio": "Food, music, travel.",
    "interests": ["food", "music", "travel"],
    "languages": ["English", "Twi"],
}, token=ta)
post("/api/profile/onboarding", {
    "age": 31, "gender": "Man", "city": "London", "country": "Ghana",
    "bio": "Food and family.",
    "interests": ["food", "music", "family"],
    "languages": ["English", "Twi"],
}, token=tb)
ok("Both users onboarded")

# ── 7. Login ──────────────────────────────────────────────────────────────────
section("Login")
login_a, _ = post("/api/auth/login", {"email": email("amara"), "password": "password123"})
assert "token" in login_a, "Login response missing token"
ok("Login succeeds with correct credentials")
post("/api/auth/login", {"email": email("amara"), "password": "wrongpass"}, expect_status=401)
ok("Login rejected with wrong password")

# ── 8. Discover ───────────────────────────────────────────────────────────────
section("Discover")
disc_resp, _ = get("/api/discover", token=ta)
assert "profiles" in disc_resp, f"Discover response missing 'profiles' key: {disc_resp}"
disc = disc_resp["profiles"]
assert isinstance(disc, list), "Discover profiles must be a list"
assert any(u["id"] == b["user"]["id"] for u in disc), "User B missing from A's discover feed"
for u in disc:
    assert "password_hash" not in u, "password_hash must not appear in discover results"
    assert "compatibility_score" in u, "compatibility_score missing"
ok(f"Discover returned {len(disc)} candidates, B visible, no private fields")

# Pagination
disc_p1, _ = get("/api/discover", token=ta, params={"page": 0})
assert "has_more" in disc_p1, "Discover response missing has_more"
ok("Discover pagination response shape correct")

# ── 9. Swipe & match ─────────────────────────────────────────────────────────
section("Swipe & Match")
swipe_a, _ = post("/api/swipe", {"target_user_id": b["user"]["id"], "action": "like"}, token=ta)
assert swipe_a["match"] is False, "Should not match on one-sided like"
ok("One-sided like: no match yet")

swipe_b, _ = post("/api/swipe", {"target_user_id": a["user"]["id"], "action": "like"}, token=tb)
assert swipe_b["match"] is True, "Mutual like should produce a match"
assert "match_id" in swipe_b, "match_id missing from match response"
match_id = swipe_b["match_id"]
ok(f"Mutual like created match {match_id}")

# Self-swipe rejected
post("/api/swipe", {"target_user_id": a["user"]["id"], "action": "like"}, token=ta, expect_status=400)
ok("Self-swipe rejected")

# ── 10. Matches list (with pagination) ────────────────────────────────────────
section("Matches list")
matches_resp, _ = get("/api/matches", token=ta)
assert "matches" in matches_resp, f"Matches response missing 'matches' key: {matches_resp}"
assert "has_more" in matches_resp, "Matches response missing 'has_more'"
matches = matches_resp["matches"]
assert isinstance(matches, list) and len(matches) >= 1, "A should have at least one match"
ok(f"Matches list: {len(matches)} match(es), has_more={matches_resp['has_more']}")

# Pagination with before cursor
oldest_created_at = matches[-1]["created_at"]
matches_p2, _ = get("/api/matches", token=ta, params={"before": oldest_created_at})
assert "matches" in matches_p2, "Paginated matches response missing 'matches'"
ok("Matches pagination response shape correct")

# ── 11. Messaging ─────────────────────────────────────────────────────────────
section("Messaging")
msg, _ = post("/api/messages", {"match_id": match_id, "text": "Hey!"}, token=ta)
assert "id" in msg, "Sent message missing id"
ok("Message sent")

msgs, _ = get(f"/api/messages/{match_id}", token=tb)
assert isinstance(msgs, list) and len(msgs) >= 1, "Recipient should see at least 1 message"
assert msgs[0]["text"] == "Hey!", f"Unexpected message text: {msgs[0]['text']}"
ok(f"Recipient sees {len(msgs)} message(s)")

# Empty message rejected
post("/api/messages", {"match_id": match_id, "text": "   "}, token=ta, expect_status=400)
ok("Empty message rejected")

# Oversized message rejected
post("/api/messages", {"match_id": match_id, "text": "x" * 2001}, token=ta, expect_status=400)
ok("Oversized message rejected")

# Non-member cannot read messages
c, _ = post("/api/auth/register", {
    "email": email("outsider"), "password": "password123", "name": "Outsider",
    "date_of_birth": "1990-01-01", "accepted_tos": True,
})
get(f"/api/messages/{match_id}", token=c["token"], expect_status=404)
ok("Non-match-member cannot read messages")

# ── 12. Report ────────────────────────────────────────────────────────────────
section("Report")
rep, _ = post("/api/report", {"target_user_id": b["user"]["id"], "reason": "Spam"}, token=ta)
assert rep.get("message"), "Report response missing message"
ok("Report submitted successfully")
# Self-report rejected
post("/api/report", {"target_user_id": a["user"]["id"], "reason": "Spam"}, token=ta, expect_status=400)
ok("Self-report rejected")

# ── 13. Block ─────────────────────────────────────────────────────────────────
section("Block")
# Register a third user to block (can't block matched user cleanly in same test flow)
d_reg, _ = post("/api/auth/register", {
    "email": email("dayo"), "password": "password123", "name": "Dayo",
    "date_of_birth": "1991-03-10", "accepted_tos": True,
})
block_resp, _ = post("/api/block", {"target_user_id": d_reg["user"]["id"]}, token=ta)
assert block_resp.get("blocked") is True, "Block response missing blocked=True"
ok("Block recorded successfully")
# Self-block rejected
post("/api/block", {"target_user_id": a["user"]["id"]}, token=ta, expect_status=400)
ok("Self-block rejected")

# ── 14. Change password + token revocation ────────────────────────────────────
section("Change password")
post("/api/auth/change-password", {
    "current_password": "password123",
    "new_password": "newpassword456",
}, token=ta)
# Old token is revoked after password change
get("/api/me", token=ta, expect_status=401)
ok("Old token revoked after password change")
# Login with new password works
login_new, _ = post("/api/auth/login", {"email": email("amara"), "password": "newpassword456"})
assert "token" in login_new
ok("Login with new password succeeds")
ta_new = login_new["token"]

# ── 15. Logout ────────────────────────────────────────────────────────────────
section("Logout")
post("/api/auth/logout", token=ta_new)
get("/api/me", token=ta_new, expect_status=401)
ok("Token revoked after logout")

# ── Done ─────────────────────────────────────────────────────────────────────
print("\n✅ All core flow tests passed\n")
