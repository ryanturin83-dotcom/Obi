
import os
import uuid
import hashlib
import logging
import io
import subprocess
import re
import json as _json
import hmac
import requests
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, List

import jwt
import bcrypt
import stripe
import redis
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect, Depends, status, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, EmailStr, field_validator, Field

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("obi-v10")

MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "obi_dating")
JWT_SECRET = os.getenv("JWT_SECRET", "dev-change-me")
_UNSAFE_SECRETS = {"dev-change-me", "", "secret", "changeme", "change-me"}
if os.getenv("ASA_ENV", "development") == "production" and JWT_SECRET in _UNSAFE_SECRETS:
    raise RuntimeError(
        "JWT_SECRET is set to an insecure default value. "
        "Set a strong random secret in your .env before running in production. "
        "Generate one with: python -c \"import secrets; print(secrets.token_hex(64))\""
    )
JWT_ALGORITHM = "HS256"
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
APP_BASE_URL = os.getenv("APP_BASE_URL", "https://yourdomain.com").rstrip("/")
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8081,http://localhost:19006").split(",") if o.strip()]
if "*" in CORS_ORIGINS:
    CORS_ORIGINS = ["http://localhost:8081", "http://localhost:19006"]

STRIPE_ENABLED = os.getenv("STRIPE_ENABLED", "false").lower() == "true"
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")
STRIPE_PRICE_GOLD = os.getenv("STRIPE_PRICE_GOLD", "")

AI_FEATURES_ENABLED = os.getenv("AI_FEATURES_ENABLED", "false").lower() == "true"
TRANSLATION_ENABLED = os.getenv("TRANSLATION_ENABLED", "false").lower() == "true"
BLOCKCHAIN_ENABLED = os.getenv("BLOCKCHAIN_ENABLED", "false").lower() == "true"
VR_FEATURES_ENABLED = os.getenv("VR_FEATURES_ENABLED", "false").lower() == "true"

# Photo upload config
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_PHOTO_BYTES = int(os.getenv("MAX_PHOTO_BYTES", str(8 * 1024 * 1024)))  # default 8 MB
MAX_PHOTO_PIXELS = int(os.getenv("MAX_PHOTO_PIXELS", "12000000"))  # e.g. 4000x3000
PHOTO_DIRECT_UPLOAD_ENABLED = os.getenv("PHOTO_DIRECT_UPLOAD_ENABLED", "false").lower() == "true"

# Admin
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "")

# ── Startup validation ────────────────────────────────────────────────────────
_ENV = os.getenv("ASA_ENV", "development")
if _ENV == "production":
    if "yourdomain.com" in APP_BASE_URL:
        raise RuntimeError(
            "APP_BASE_URL is still set to the placeholder 'yourdomain.com'. "
            "Set APP_BASE_URL to your real domain in .env before running in production. "
            "Email verification and deletion links will be broken otherwise."
        )

# Warn (don't crash) if email is not configured — it's critical for verification flow
_EMAIL_CONFIGURED = bool(
    os.getenv("RESEND_API_KEY") or (os.getenv("SMTP_HOST") and os.getenv("SMTP_USER") and os.getenv("SMTP_PASS"))
)
if not _EMAIL_CONFIGURED:
    logger.warning(
        "No email provider configured (RESEND_API_KEY or SMTP_HOST/SMTP_USER/SMTP_PASS). "
        "Verification emails will only be logged. Set RESEND_API_KEY for production."
    )

# Moderation
MODERATION_WORKER_ENABLED = os.getenv("MODERATION_WORKER_ENABLED", "false").lower() == "true"
MODERATION_PROVIDER_URL = os.getenv("MODERATION_PROVIDER_URL", "").rstrip("/")
MODERATION_PROVIDER_API_KEY = os.getenv("MODERATION_PROVIDER_API_KEY", "")
MODERATION_PROVIDER_TIMEOUT_SECONDS = float(os.getenv("MODERATION_PROVIDER_TIMEOUT_SECONDS", "5"))
MODERATION_BLOCK_ON_PROVIDER_ERROR = os.getenv("MODERATION_BLOCK_ON_PROVIDER_ERROR", "false").lower() == "true"

# Alerting
ALERT_WEBHOOK_URL = os.getenv("ALERT_WEBHOOK_URL", "")
ALERT_WEBHOOK_SECRET = os.getenv("ALERT_WEBHOOK_SECRET", "")
ALERT_MIN_SEVERITY = os.getenv("ALERT_MIN_SEVERITY", "critical")

# Content moderation patterns
BANNED_CONTENT_PATTERNS = [p.strip().lower() for p in os.getenv("BANNED_CONTENT_PATTERNS", "").split(",") if p.strip()]
URL_RE = re.compile(r"https?://|www\.", re.IGNORECASE)

# Photo storage (S3 or Cloudflare R2)
STORAGE_BUCKET = os.getenv("STORAGE_BUCKET", "")
STORAGE_ENDPOINT_URL = os.getenv("STORAGE_ENDPOINT_URL", "")  # leave blank for AWS S3
STORAGE_ACCESS_KEY = os.getenv("STORAGE_ACCESS_KEY", "")
STORAGE_SECRET_KEY_S3 = os.getenv("STORAGE_SECRET_KEY_S3", "")
STORAGE_PUBLIC_BASE_URL = os.getenv("STORAGE_PUBLIC_BASE_URL", "").rstrip("/")
STORAGE_ENABLED = bool(STORAGE_BUCKET and STORAGE_ACCESS_KEY and STORAGE_SECRET_KEY_S3)

if STORAGE_ENABLED:
    import boto3
    from botocore.config import Config as BotoConfig
    _s3_kwargs = dict(
        aws_access_key_id=STORAGE_ACCESS_KEY,
        aws_secret_access_key=STORAGE_SECRET_KEY_S3,
        config=BotoConfig(signature_version="s3v4"),
    )
    if STORAGE_ENDPOINT_URL:
        _s3_kwargs["endpoint_url"] = STORAGE_ENDPOINT_URL
    s3_client = boto3.client("s3", **_s3_kwargs)
else:
    s3_client = None

stripe.api_key = STRIPE_SECRET_KEY if STRIPE_SECRET_KEY else None

mongo_client = AsyncIOMotorClient(
    MONGO_URL,
    maxPoolSize=int(os.getenv("MONGO_MAX_POOL_SIZE", "100")),
    minPoolSize=int(os.getenv("MONGO_MIN_POOL_SIZE", "5")),
)
db = mongo_client[DB_NAME]

try:
    redis_client = redis.Redis.from_url(
        REDIS_URL,
        decode_responses=True,
        socket_timeout=2,
        socket_connect_timeout=2,
        retry_on_timeout=True,
    )
except Exception:
    redis_client = None

from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Start background tasks and ensure DB indexes on startup."""
    import asyncio as _asyncio
    # Keep a reference to the task so it can be cleanly cancelled on shutdown
    _pubsub_task = _asyncio.create_task(_redis_pubsub_listener())
    try:
        await db.users.create_index("email", unique=True)
        await db.users.create_index("id", unique=True)
        await db.users.create_index([("location", "2dsphere")])
        await db.users.create_index([("onboarded", 1), ("banned", 1), ("deleted", 1)])
        await db.users.create_index("languages")
        await db.swipes.create_index([("user_id", 1), ("target_user_id", 1)], unique=True)
        await db.matches.create_index("users")
        await db.matches.create_index("id", unique=True)
        await db.messages.create_index([("match_id", 1), ("created_at", 1)])
        await db.messages.create_index([("moderation_status", 1)])
        await db.reports.create_index([("resolved", 1), ("created_at", -1)])
        await db.account_deletions.create_index("token", unique=True)
        # TTL index: auto-expire deletion request records 1 hour after expiry
        await db.account_deletions.create_index("expires_at", expireAfterSeconds=0)
        await db.email_verifications.create_index("token", unique=True)
        await db.email_verifications.create_index("user_id")
        # TTL: auto-expire unverified tokens after 24 h
        await db.email_verifications.create_index("expires_at", expireAfterSeconds=0)
        # TTL index: auto-expire security_events after 90 days
        await db.security_events.create_index("created_at", expireAfterSeconds=7776000)
        await db.complaints.create_index([("user_id", 1), ("created_at", -1)])
        await db.complaints.create_index("reference_id", unique=True)
        # Blocks collection — allows efficient lookup in both directions
        await db.blocks.create_index([("blocker_id", 1), ("blocked_id", 1)], unique=True)
        await db.blocks.create_index("blocked_id")
        logger.info("Indexes ensured")
    except Exception as exc:
        logger.warning("Index creation failed: %s", exc)
    yield  # server runs here
    # Clean shutdown: cancel the pubsub listener
    _pubsub_task.cancel()
    try:
        await _pubsub_task
    except _asyncio.CancelledError:
        pass

app = FastAPI(title="Obi Dating API v10", version="10.0", lifespan=lifespan)
security = HTTPBearer(auto_error=False)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Well-known files for iOS Associated Domains + Android Digital Asset Links ──
# Apple fetches AASA on every fresh install — must be:
#   • served at exactly /.well-known/apple-app-site-association
#   • Content-Type: application/json
#   • NO redirect (even http→https breaks it)
# Mount the static directory for any other assets
import pathlib
_STATIC_DIR = pathlib.Path(__file__).parent / "static"

@app.get("/.well-known/apple-app-site-association", include_in_schema=False)
async def apple_app_site_association():
    aasa_path = _STATIC_DIR / ".well-known" / "apple-app-site-association"
    return FileResponse(
        aasa_path,
        media_type="application/json",
        headers={"Cache-Control": "public, max-age=3600"},
    )

@app.get("/.well-known/assetlinks.json", include_in_schema=False)
async def android_asset_links():
    links_path = _STATIC_DIR / ".well-known" / "assetlinks.json"
    return FileResponse(
        links_path,
        media_type="application/json",
        headers={"Cache-Control": "public, max-age=3600"},
    )


@app.middleware("http")
async def global_abuse_guard(request: Request, call_next):
    """Cheap global write throttle + security headers + request-ID injection."""
    # Attach a per-request ID for log correlation across frontend and backend.
    # Clients may send their own X-Request-ID; we echo it back if present.
    request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    if request.method in {"POST", "PUT", "PATCH", "DELETE"} and not request.url.path.startswith("/api/stripe/webhook"):
        await rate_limit(request, "global-write", int(os.getenv("GLOBAL_WRITE_LIMIT", "240")), 300)
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str
    date_of_birth: str  # ISO date string "YYYY-MM-DD" — used for age-gate; stored as hashed value only
    accepted_tos: bool = False

    @field_validator("password")
    @classmethod
    def password_min(cls, value: str) -> str:
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters")
        return value

    @field_validator("name")
    @classmethod
    def name_not_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Name is required")
        return value

    @field_validator("date_of_birth")
    @classmethod
    def dob_format(cls, value: str) -> str:
        try:
            datetime.strptime(value.strip(), "%Y-%m-%d")
        except ValueError:
            raise ValueError("date_of_birth must be in YYYY-MM-DD format")
        return value.strip()

    @field_validator("accepted_tos")
    @classmethod
    def must_accept_tos(cls, value: bool) -> bool:
        if not value:
            raise ValueError("You must accept the Terms of Service and Privacy Policy to create an account")
        return value

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def new_password_min(cls, value: str) -> str:
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters")
        return value

class OnboardingRequest(BaseModel):
    age: Optional[int] = None
    gender: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    tribe: Optional[str] = None
    bio: Optional[str] = None
    occupation: Optional[str] = None
    interests: List[str] = Field(default_factory=list)
    languages: List[str] = Field(default_factory=list)
    latitude: Optional[float] = None
    longitude: Optional[float] = None

class FiltersRequest(BaseModel):
    max_age: Optional[int] = 45
    max_distance: Optional[int] = 50
    language: Optional[str] = None
    country: Optional[str] = None
    gender: Optional[str] = None

class SwipeRequest(BaseModel):
    target_user_id: str
    action: str

class MessageRequest(BaseModel):
    match_id: str
    text: str

class PushTokenRequest(BaseModel):
    token: str

class ReportRequest(BaseModel):
    target_user_id: str
    reason: str

class BlockRequest(BaseModel):
    target_user_id: str

class AccountDeletionRequest(BaseModel):
    email: EmailStr

class AccountDeletionConfirmRequest(BaseModel):
    token: str

class TranslateRequest(BaseModel):
    text: str
    target_language: str
    source_language: Optional[str] = None

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _client_ip(request: Optional[Request] = None, websocket: Optional[WebSocket] = None) -> str:
    client = getattr(request or websocket, "client", None)
    return client.host if client else "unknown"

def security_log(event: str, **fields) -> None:
    safe_fields = {k: v for k, v in fields.items() if k not in {"token", "password", "authorization"}}
    logger.warning("security_event=%s %s", event, safe_fields)


def _severity_rank(severity: str) -> int:
    return {"debug": 0, "info": 1, "warning": 2, "error": 3, "critical": 4}.get((severity or "info").lower(), 1)


async def send_alert(event: str, severity: str, payload: dict) -> None:
    """Send high-severity security/ops alerts to a generic webhook."""
    if not ALERT_WEBHOOK_URL:
        return
    if _severity_rank(severity) < _severity_rank(ALERT_MIN_SEVERITY):
        return
    body = {"event": event, "severity": severity, "service": "obi-api", "payload": payload, "created_at": now_iso()}
    headers = {"Content-Type": "application/json"}
    raw = _json.dumps(body, default=str).encode("utf-8")
    if ALERT_WEBHOOK_SECRET:
        headers["X-ASA-Signature"] = hmac.new(ALERT_WEBHOOK_SECRET.encode("utf-8"), raw, "sha256").hexdigest()
    try:
        import asyncio as _asyncio
        loop = _asyncio.get_running_loop()
        await loop.run_in_executor(None, lambda: requests.post(ALERT_WEBHOOK_URL, data=raw, headers=headers, timeout=3))
        await metric_incr("alerts_sent")
    except Exception as exc:
        logger.warning("alert delivery failed: %s", exc)


async def audit_event(event: str, request: Optional[Request] = None, websocket: Optional[WebSocket] = None, user_id: Optional[str] = None, severity: str = "info", **fields) -> None:
    """Persist security/abuse signals and emit structured logs for observability."""
    safe_fields = {k: v for k, v in fields.items() if k not in {"token", "password", "authorization"}}
    doc = {
        "id": str(uuid.uuid4()),
        "event": event,
        "severity": severity,
        "user_id": user_id,
        "ip": _client_ip(request=request, websocket=websocket),
        "path": str(request.url.path) if request else None,
        "created_at": now_iso(),
        "fields": safe_fields,
    }
    logger.warning("security_audit=%s", _json.dumps(doc, default=str))
    await send_alert(event, severity, doc)
    try:
        await db.security_events.insert_one(doc)
    except Exception as exc:
        logger.warning("security audit insert failed: %s", exc)

async def metric_incr(name: str, amount: int = 1) -> None:
    if not redis_client:
        return
    try:
        await _redis_run(redis_client.incrby, f"metric:{name}", amount)
    except Exception:
        pass

async def require_admin(x_admin_key: Optional[str] = Header(default=None)) -> None:
    if not ADMIN_API_KEY or x_admin_key != ADMIN_API_KEY:
        raise HTTPException(403, "Admin access required")

async def create_moderation_job(kind: str, user_id: str, payload: dict, priority: int = 50) -> dict:
    job = {
        "id": str(uuid.uuid4()),
        "kind": kind,
        "user_id": user_id,
        "payload": payload,
        "priority": priority,
        "status": "queued",
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    await db.moderation_jobs.insert_one(job)
    await metric_incr("moderation_jobs_queued")
    return job

def basic_content_flags(text: str) -> List[str]:
    text_l = (text or "").lower()
    flags = []
    if URL_RE.search(text_l):
        flags.append("contains_url")
    for pattern in BANNED_CONTENT_PATTERNS:
        if pattern and pattern in text_l:
            flags.append(f"blocked_pattern:{pattern[:24]}")
    if len(text or "") > 1000:
        flags.append("too_long")
    return flags


async def external_moderation(kind: str, payload: dict) -> dict:
    """Provider-ready moderation hook.

    Expected provider response: {"approved": bool, "flags": ["..."], "score": 0.0-1.0}.
    Configure MODERATION_PROVIDER_URL to point at a moderation provider or an internal wrapper.
    """
    if not MODERATION_PROVIDER_URL:
        return {"approved": True, "flags": [], "provider": None}
    headers = {"Content-Type": "application/json"}
    if MODERATION_PROVIDER_API_KEY:
        headers["Authorization"] = f"Bearer {MODERATION_PROVIDER_API_KEY}"
    body = {"kind": kind, "payload": payload, "created_at": now_iso()}
    try:
        import asyncio as _asyncio
        loop = _asyncio.get_running_loop()
        resp = await loop.run_in_executor(None, lambda: requests.post(MODERATION_PROVIDER_URL, json=body, headers=headers, timeout=MODERATION_PROVIDER_TIMEOUT_SECONDS))
        resp.raise_for_status()
        result = resp.json()
        flags = [str(f)[:80] for f in result.get("flags", []) if str(f).strip()]
        approved = bool(result.get("approved", not flags))
        await metric_incr("moderation_provider_calls")
        if flags:
            await metric_incr("moderation_provider_flags")
        return {"approved": approved, "flags": flags, "score": result.get("score"), "provider": MODERATION_PROVIDER_URL}
    except Exception as exc:
        logger.error("external moderation provider failed: %s", exc)
        await metric_incr("moderation_provider_errors")
        if MODERATION_BLOCK_ON_PROVIDER_ERROR:
            raise HTTPException(503, "Moderation service unavailable")
        return {"approved": True, "flags": ["provider_unavailable"], "provider": MODERATION_PROVIDER_URL}

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False

def create_access_token(user_id: str, email: str, token_version: int = 0) -> str:
    return jwt.encode(
        {
            "sub": user_id,
            "email": email,
            "type": "access",
            "token_version": token_version,
            "exp": datetime.now(timezone.utc) + timedelta(days=30),
        },
        JWT_SECRET,
        algorithm=JWT_ALGORITHM,
    )

def public_user(user: dict) -> dict:
    if not user:
        return {}
    safe = dict(user)
    for private_key in ("_id", "password_hash", "push_token", "stripe_customer_id", "identity_hash", "fraud_flags", "fraud_action"):
        safe.pop(private_key, None)
    return safe

import asyncio as _asyncio
import json as _json

async def _redis_run(fn, *args, **kwargs):
    """Run a synchronous redis-py call in a thread so it never blocks the event loop."""
    loop = _asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: fn(*args, **kwargs))

async def cache_get_json(key: str):
    try:
        if not redis_client:
            return None
        raw = await _redis_run(redis_client.get, key)
        return _json.loads(raw) if raw else None
    except Exception:
        return None

async def cache_set_json(key: str, value, ttl: int = 30):
    try:
        if not redis_client:
            return
        serialised = _json.dumps(value, default=str)
        await _redis_run(redis_client.setex, key, ttl, serialised)
    except Exception:
        pass

async def cache_delete(key: str):
    try:
        if not redis_client:
            return
        await _redis_run(redis_client.delete, key)
    except Exception:
        pass

async def rate_limit(request: Request, key: str, limit: int = 20, window_seconds: int = 60, actor_id: Optional[str] = None):
    """Redis-backed rate limiter. Uses user id when available plus IP fallback."""
    if not redis_client:
        return
    ip = _client_ip(request=request)
    identities = [f"ip:{ip}"]
    if actor_id:
        identities.insert(0, f"user:{actor_id}")
    try:
        for ident in identities:
            redis_key = f"rate:{key}:{ident}"
            pipe = redis_client.pipeline()
            pipe.incr(redis_key)
            pipe.ttl(redis_key)
            count, ttl_remaining = await _redis_run(pipe.execute)
            if ttl_remaining < 0:
                await _redis_run(redis_client.expire, redis_key, window_seconds)
            if count > limit:
                security_log("rate_limit_hit", key=key, identity=ident, ip=ip, actor_id=actor_id, limit=limit, window_seconds=window_seconds)
                await metric_incr("rate_limit_hits")
                await audit_event("rate_limit_hit", request=request, user_id=actor_id, severity="warning", key=key, identity=ident, limit=limit, window_seconds=window_seconds)
                raise HTTPException(429, "Too many requests. Please try again later.")
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Rate limiter unavailable for key=%s: %s", key, exc)
        return

async def ws_rate_limit(user_id: str, key: str, limit: int = 60, window_seconds: int = 60) -> bool:
    if not redis_client:
        return True
    redis_key = f"rate:ws:{key}:user:{user_id}"
    try:
        pipe = redis_client.pipeline()
        pipe.incr(redis_key)
        pipe.ttl(redis_key)
        count, ttl_remaining = await _redis_run(pipe.execute)
        if ttl_remaining < 0:
            await _redis_run(redis_client.expire, redis_key, window_seconds)
        if count > limit:
            security_log("rate_limit_hit", key=f"ws:{key}", actor_id=user_id, limit=limit, window_seconds=window_seconds)
            await metric_incr("ws_rate_limit_hits")
            return False
    except Exception as exc:
        logger.warning("WS rate limiter unavailable for user=%s: %s", user_id, exc)
    return True

async def get_current_user(request: Request, creds: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> dict:
    token = creds.credentials if creds else None
    if not token:
        header = request.headers.get("Authorization", "")
        if header.startswith("Bearer "):
            token = header[7:]
    if not token:
        security_log("auth_failure", reason="missing_token", ip=_client_ip(request=request), path=str(request.url.path))
        await metric_incr("auth_failures")
        await audit_event("auth_failure", request=request, severity="warning", reason="missing_token")
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(401, "Invalid token")
        user = await db.users.find_one({"id": payload["sub"]})
        if not user:
            raise HTTPException(401, "User not found")
        if int(payload.get("token_version", -1)) != int(user.get("token_version", 0)):
            security_log("auth_failure", reason="token_revoked", user_id=user.get("id"), ip=_client_ip(request=request), path=str(request.url.path))
            await metric_incr("auth_failures")
            await audit_event("auth_failure", request=request, user_id=user.get("id"), severity="warning", reason="token_revoked")
            raise HTTPException(401, "Token revoked")
        if user.get("banned") or user.get("deleted"):
            raise HTTPException(403, "Account unavailable")
        return user
    except jwt.ExpiredSignatureError:
        security_log("auth_failure", reason="token_expired", ip=_client_ip(request=request), path=str(request.url.path))
        await metric_incr("auth_failures")
        await audit_event("auth_failure", request=request, severity="warning", reason="token_expired")
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        security_log("auth_failure", reason="invalid_token", ip=_client_ip(request=request), path=str(request.url.path))
        await metric_incr("auth_failures")
        await audit_event("auth_failure", request=request, severity="warning", reason="invalid_token")
        raise HTTPException(401, "Invalid token")

async def ensure_match_member(match_id: str, user_id: str) -> dict:
    match = await db.matches.find_one({"id": match_id, "users": user_id})
    if not match:
        raise HTTPException(404, "Match not found")
    if match.get("blocked"):
        raise HTTPException(403, "This conversation is no longer available")
    return match

def compatibility_score(user: dict, candidate: dict) -> dict:
    score = 40
    reasons = []
    shared_interests = sorted(list(set(user.get("interests", []) or []) & set(candidate.get("interests", []) or [])))
    if shared_interests:
        score += min(len(shared_interests) * 8, 24)
        reasons.append(f"Shared interests: {', '.join(shared_interests[:3])}")
    shared_langs = sorted(list(set(user.get("languages", []) or []) & set(candidate.get("languages", []) or [])))
    if shared_langs:
        score += 14
        reasons.append(f"Shared language: {shared_langs[0]}")
    if user.get("country") and candidate.get("country") and user.get("country") == candidate.get("country"):
        score += 10
        reasons.append("Similar cultural background")
    if user.get("city") and candidate.get("city") and user.get("city") == candidate.get("city"):
        score += 8
        reasons.append("Same city")
    if candidate.get("last_active_at"):
        score += 5
        reasons.append("Recently active")
    for field in ("bio", "photo_url", "age", "city"):
        if candidate.get(field):
            score += 2
    score = max(1, min(99, int(score)))
    if not reasons:
        reasons.append("Potential match based on profile signals")
    return {
        "score": score,
        "label": "Great match" if score >= 80 else "Good match" if score >= 65 else "Potential match",
        "reasons": reasons,
    }

def build_discover_query(user: dict) -> dict:
    filters = user.get("filters") or {}
    query = {"id": {"$ne": user["id"]}, "onboarded": True, "banned": {"$ne": True}, "deleted": {"$ne": True}, "shadowbanned": {"$ne": True}}
    if filters.get("max_age"):
        query["age"] = {"$lte": int(filters["max_age"])}
    if filters.get("language"):
        query["languages"] = {"$in": [filters["language"]]}
    if filters.get("country"):
        query["country"] = filters["country"]
    if filters.get("gender"):
        query["gender"] = filters["gender"]
    return query

@app.exception_handler(Exception)
async def global_error_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error: %s", exc)
    return JSONResponse(status_code=500, content={"message": "Something went wrong"})

@app.get("/")
async def root():
    return {"app": "Obi API", "version": "9.0", "status": "ok"}


@app.get("/api/admin/metrics")
async def admin_metrics(_: None = Depends(require_admin)):
    """Minimal operational view for launch: abuse, auth, rate-limit, upload, and moderation counters."""
    metrics = {}
    if redis_client:
        try:
            keys = await _redis_run(redis_client.keys, "metric:*")
            for key in keys:
                metrics[key.replace("metric:", "", 1)] = int(await _redis_run(redis_client.get, key) or 0)
        except Exception as exc:
            logger.warning("metrics read failed: %s", exc)
    queued = await db.moderation_jobs.count_documents({"status": "queued"})
    flagged_messages = await db.messages.count_documents({"moderation_status": "flagged"})
    recent_security_events = await db.security_events.find({}, {"_id": 0}).sort("created_at", -1).limit(50).to_list(50)
    return {"metrics": metrics, "moderation_queue": queued, "flagged_messages": flagged_messages, "recent_security_events": recent_security_events}

@app.get("/api/admin/moderation/jobs")
async def admin_moderation_jobs(status_filter: str = "queued", _: None = Depends(require_admin)):
    query = {} if status_filter == "all" else {"status": status_filter}
    jobs = await db.moderation_jobs.find(query, {"_id": 0}).sort([("priority", -1), ("created_at", 1)]).limit(100).to_list(100)
    return {"jobs": jobs}

@app.post("/api/admin/moderation/jobs/{job_id}/resolve")
async def admin_resolve_moderation_job(job_id: str, body: dict, request: Request, _: None = Depends(require_admin)):
    action = (body.get("action") or "").lower().strip()
    if action not in {"approve", "reject", "ban_user", "shadowban_user"}:
        raise HTTPException(400, "action must be approve, reject, ban_user, or shadowban_user")
    job = await db.moderation_jobs.find_one({"id": job_id})
    if not job:
        raise HTTPException(404, "Moderation job not found")
    user_id = job.get("user_id")
    updates = {"status": "resolved", "action": action, "resolution_note": body.get("note"), "updated_at": now_iso()}
    await db.moderation_jobs.update_one({"id": job_id}, {"$set": updates})
    if action == "approve" and job.get("kind") == "photo":
        await db.users.update_one({"id": user_id}, {"$set": {"photo_moderation_status": "approved"}})
    if action == "reject" and job.get("kind") == "photo":
        await db.users.update_one({"id": user_id}, {"$unset": {"photo_url": ""}, "$set": {"photo_moderation_status": "rejected"}})
    if action == "reject" and job.get("kind") == "message":
        msg_id = (job.get("payload") or {}).get("message_id")
        if msg_id:
            await db.messages.update_one({"id": msg_id}, {"$set": {"moderation_status": "rejected"}})
    if action == "ban_user":
        await db.users.update_one({"id": user_id}, {"$set": {"banned": True, "banned_at": now_iso()}, "$inc": {"token_version": 1}})
    if action == "shadowban_user":
        await db.users.update_one({"id": user_id}, {"$set": {"shadowbanned": True, "shadowbanned_at": now_iso()}})
    await audit_event("moderation_job_resolved", request=request, user_id=user_id, severity="warning", job_id=job_id, action=action)
    return {"resolved": True, "job_id": job_id, "action": action}

@app.post("/api/auth/register")
async def register(body: RegisterRequest, request: Request):
    await rate_limit(request, "register", 5, 300)

    # --- Age gate (must be 18+) ---
    try:
        dob = datetime.strptime(body.date_of_birth, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(400, "Invalid date_of_birth")
    today = datetime.now(timezone.utc).date()
    age_years = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    if age_years < 18:
        security_log("register_underage", ip=_client_ip(request=request))
        raise HTTPException(400, "You must be at least 18 years old to register")

    # --- ToS already validated by the model validator, but double-check ---
    if not body.accepted_tos:
        raise HTTPException(400, "You must accept the Terms of Service and Privacy Policy")

    email = body.email.lower().strip()
    if await db.users.find_one({"email": email}):
        raise HTTPException(400, "Email already registered")

    user_id = str(uuid.uuid4())
    user = {
        "id": user_id,
        "email": email,
        "password_hash": hash_password(body.password),
        "name": body.name,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "onboarded": False,
        "banned": False,
        "deleted": False,
        "is_gold": False,
        "email_verified": False,
        "accepted_tos_at": now_iso(),
        "accepted_tos_version": "1.0",
        "filters": {"max_age": 45, "max_distance": 50, "language": None, "country": None, "gender": None},
        "interests": [],
        "languages": [],
        "popularity_score": 0,
        "boost_until": 0,
        "last_active_at": now_iso(),
        "verification_level": 0,
        "verified": False,
        "blocked_users": [],
        "token_version": 0,
    }
    await db.users.insert_one(user)

    # --- Issue email verification token ---
    verification_token = uuid.uuid4().hex + uuid.uuid4().hex
    await db.email_verifications.insert_one({
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "email": email,
        "token": verification_token,
        "created_at": now_iso(),
        "expires_at": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
        "used": False,
    })
    verify_url = f"{APP_BASE_URL}/verify-email?token={verification_token}"
    await send_email(
        to=email,
        subject="Verify your Obi email address",
        body_text=(
            f"Hi {body.name},\n\n"
            "Welcome to Obi! Please verify your email address by clicking the link below "
            "(link expires in 24 hours):\n\n"
            f"{verify_url}\n\n"
            "If you did not create an account, you can safely ignore this email.\n\n"
            "— The Obi Team"
        ),
    )

    # Return a limited token that only allows profile completion, NOT discovery.
    # Full access is granted after email_verified = True (see /api/auth/verify-email).
    token = create_access_token(user["id"], email, user.get("token_version", 0))
    return {
        "token": token,
        "user": public_user(user),
        "email_verification_required": True,
        "message": f"Account created. A verification link has been sent to {email}. Please verify before you can start discovering.",
    }

@app.post("/api/auth/login")
async def login(body: LoginRequest, request: Request):
    await rate_limit(request, "login", 10, 300)
    user = await db.users.find_one({"email": body.email.lower().strip()})
    if not user or not verify_password(body.password, user.get("password_hash", "")):
        raise HTTPException(401, "Invalid email or password")
    if user.get("banned") or user.get("deleted"):
        raise HTTPException(403, "Account unavailable")
    await db.users.update_one({"id": user["id"]}, {"$set": {"last_active_at": now_iso()}})
    token = create_access_token(user["id"], user["email"], user.get("token_version", 0))
    return {"token": token, "user": public_user(user)}

@app.post("/api/auth/verify-email")
async def verify_email(request: Request):
    """Consume a single-use email verification token and mark the account as verified."""
    await rate_limit(request, "verify-email", 10, 300)
    body = await request.json()
    token = (body.get("token") or "").strip()
    if not token:
        raise HTTPException(400, "Verification token is required")
    record = await db.email_verifications.find_one({"token": token, "used": False})
    if not record:
        raise HTTPException(400, "Invalid or expired verification token")
    if record.get("expires_at") and record["expires_at"] < now_iso():
        raise HTTPException(400, "Verification link has expired — please request a new one")
    user_id = record["user_id"]
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"email_verified": True, "updated_at": now_iso()}},
    )
    await db.email_verifications.update_one({"token": token}, {"$set": {"used": True, "used_at": now_iso()}})
    user = await db.users.find_one({"id": user_id})
    return {"verified": True, "user": public_user(user) if user else None}

@app.post("/api/auth/resend-verification")
async def resend_verification(request: Request, user: dict = Depends(get_current_user)):
    """Resend the email verification link for the authenticated user."""
    await rate_limit(request, "resend-verification", 3, 3600, actor_id=user["id"])
    if user.get("email_verified"):
        return {"message": "Email is already verified"}
    # Invalidate any existing unused tokens for this user
    await db.email_verifications.update_many(
        {"user_id": user["id"], "used": False},
        {"$set": {"used": True, "used_at": now_iso()}},
    )
    verification_token = uuid.uuid4().hex + uuid.uuid4().hex
    await db.email_verifications.insert_one({
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "email": user["email"],
        "token": verification_token,
        "created_at": now_iso(),
        "expires_at": (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(),
        "used": False,
    })
    verify_url = f"{APP_BASE_URL}/verify-email?token={verification_token}"
    await send_email(
        to=user["email"],
        subject="Verify your Obi email address",
        body_text=(
            f"Hi {user.get('name', 'there')},\n\n"
            "Here's your new email verification link (expires in 24 hours):\n\n"
            f"{verify_url}\n\n"
            "— The Obi Team"
        ),
    )
    return {"message": "Verification email resent"}



@app.get("/api/auth/me", include_in_schema=False)
async def auth_me(user: dict = Depends(get_current_user)):
    """Deprecated alias — use GET /api/me instead."""
    return public_user(user)

@app.post("/api/auth/logout")
async def logout(request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "logout", 10, 300, actor_id=user["id"])
    await db.users.update_one({"id": user["id"]}, {"$inc": {"token_version": 1}, "$set": {"updated_at": now_iso()}})
    return {"logged_out": True}

@app.post("/api/auth/change-password")
async def change_password(body: ChangePasswordRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "change-password", 5, 3600, actor_id=user["id"])
    if not verify_password(body.current_password, user.get("password_hash", "")):
        raise HTTPException(401, "Current password is incorrect")
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"password_hash": hash_password(body.new_password), "updated_at": now_iso()}, "$inc": {"token_version": 1}},
    )
    return {"password_changed": True}


@app.get("/api/me")
async def me(user: dict = Depends(get_current_user)):
    """Return the authenticated user's safe profile. Used by smoke tests and clients."""
    return public_user(user)

@app.post("/api/profile/onboarding")
async def onboarding(body: OnboardingRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "onboarding", 12, 3600, actor_id=user["id"])
    if body.age is None or body.age < 18:
        raise HTTPException(400, "You must be 18 or older to use Obi.")
    if not (body.gender or "").strip():
        raise HTTPException(400, "Gender is required")
    if not (body.city or "").strip():
        raise HTTPException(400, "City is required")
    if not (body.country or "").strip():
        raise HTTPException(400, "Country is required")
    if len([i for i in body.interests if i.strip()]) < 3:
        raise HTTPException(400, "Choose at least 3 interests")
    update = body.model_dump(exclude_none=True)
    update["onboarded"] = True
    update["updated_at"] = now_iso()
    if body.latitude is not None and body.longitude is not None:
        update["location"] = {"type": "Point", "coordinates": [body.longitude, body.latitude]}
        update.pop("latitude", None)
        update.pop("longitude", None)
    await db.users.update_one({"id": user["id"]}, {"$set": update})
    # Invalidate any stale discover cache — profile fields (interests, city, etc.)
    # affect both what this user sees and how they appear in others' feeds.
    updated_user = await db.users.find_one({"id": user["id"]})
    await cache_delete(_discover_cache_key(updated_user))
    return public_user(updated_user)

@app.put("/api/profile/filters")
async def update_filters(body: FiltersRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "profile-filters", 30, 300, actor_id=user["id"])
    new_filters = {**(user.get("filters") or {}), **body.model_dump(exclude_none=True)}
    await db.users.update_one({"id": user["id"]}, {"$set": {"filters": new_filters, "updated_at": now_iso()}})
    return {"filters": new_filters}

def _discover_cache_key(user: dict) -> str:
    return f"discover:{user['id']}:{hashlib.md5(str(user.get('filters', {})).encode()).hexdigest()}"

@app.get("/api/discover")
async def discover(user: dict = Depends(get_current_user), page: int = 0):
    """Return up to 20 ranked candidates.

    Use `page=N` (0-indexed) to load subsequent pages. Pages are deterministic
    within a session because they are sliced from the same sorted candidate list
    that is cached for 5 minutes.  Pass `page=0` (or omit) to reset.
    """
    if not user.get("email_verified"):
        raise HTTPException(403, "Please verify your email before discovering matches.")
    if not user.get("onboarded"):
        raise HTTPException(403, "Complete your profile before discovering matches.")
    page = max(0, page)
    cache_key = _discover_cache_key(user)
    cached = await cache_get_json(cache_key)
    if cached:
        page_size = 20
        start = page * page_size
        result = cached[start: start + page_size]
        return {"profiles": result, "page": page, "has_more": (start + page_size) < len(cached)}
    query = build_discover_query(user)
    already_swiped = await db.swipes.find({"user_id": user["id"]}, {"_id": 0, "target_user_id": 1}).to_list(1000)
    excluded_ids = [s["target_user_id"] for s in already_swiped]
    # Fetch blocks from dedicated collection (not inline user array)
    blocks_out = await db.blocks.find({"blocker_id": user["id"]}, {"_id": 0, "blocked_id": 1}).to_list(5000)
    blocks_in = await db.blocks.find({"blocked_id": user["id"]}, {"_id": 0, "blocker_id": 1}).to_list(5000)
    excluded_ids.extend(b["blocked_id"] for b in blocks_out)
    excluded_ids.extend(b["blocker_id"] for b in blocks_in)  # also hide users who blocked us
    if excluded_ids:
        query["id"]["$nin"] = list(set(excluded_ids))
    projection = {"_id": 0, "id": 1, "name": 1, "age": 1, "city": 1, "country": 1, "gender": 1, "bio": 1, "interests": 1, "languages": 1, "photo_url": 1, "popularity_score": 1, "boost_until": 1, "last_active_at": 1}
    candidates = await db.users.find(query, projection).limit(100).to_list(100)
    for c in candidates:
        comp = compatibility_score(user, c)
        c["compatibility_score"] = comp["score"]
        c["compatibility_label"] = comp["label"]
        if user.get("is_gold"):
            c["compatibility_reasons"] = comp["reasons"][:3]
    candidates.sort(key=lambda c: (c.get("compatibility_score", 0), c.get("popularity_score", 0)), reverse=True)
    # Cache the full sorted list; slice per-page so clients can paginate
    await cache_set_json(cache_key, candidates, ttl=300)
    page_size = 20
    start = page * page_size
    result = candidates[start: start + page_size]
    return {"profiles": result, "page": page, "has_more": (start + page_size) < len(candidates)}

@app.get("/api/compatibility/{candidate_id}")
async def compatibility_detail(candidate_id: str, user: dict = Depends(get_current_user)):
    candidate = await db.users.find_one({"id": candidate_id, "banned": {"$ne": True}, "deleted": {"$ne": True}, "shadowbanned": {"$ne": True}})
    if not candidate:
        raise HTTPException(404, "User not found")
    result = compatibility_score(user, candidate)
    if not user.get("is_gold"):
        return {"score": result["score"], "label": result["label"], "locked_reasons": True, "message": "Upgrade to Gold to see why you match."}
    return result

@app.post("/api/swipe")
async def swipe(body: SwipeRequest, request: Request, user: dict = Depends(get_current_user)):
    if not user.get("email_verified"):
        raise HTTPException(403, "Please verify your email before swiping.")
    if not user.get("onboarded"):
        raise HTTPException(403, "Complete your profile before swiping.")
    await rate_limit(request, "swipe", 120, 300, actor_id=user["id"])
    if body.action not in ("like", "pass"):
        raise HTTPException(400, "Invalid swipe action")
    if body.target_user_id == user["id"]:
        raise HTTPException(400, "You cannot swipe on yourself")
    target = await db.users.find_one({"id": body.target_user_id, "banned": {"$ne": True}, "deleted": {"$ne": True}, "shadowbanned": {"$ne": True}})
    if not target:
        raise HTTPException(404, "User not found")
    # Read the previous swipe (if any) before upserting so we know whether this is a new like
    previous_swipe = await db.swipes.find_one(
        {"user_id": user["id"], "target_user_id": body.target_user_id},
        {"action": 1},
    )
    await db.swipes.update_one(
        {"user_id": user["id"], "target_user_id": body.target_user_id},
        {"$set": {"action": body.action, "updated_at": now_iso()}, "$setOnInsert": {"created_at": now_iso()}},
        upsert=True,
    )
    # Invalidate discover cache so the swiped profile is excluded on the next load
    swipe_user = await db.users.find_one({"id": user["id"]}, {"filters": 1})
    if swipe_user:
        await cache_delete(_discover_cache_key(swipe_user))
    if body.action == "like":
        # Only increment popularity for a genuinely new like — not a pass→like change on an existing record
        was_already_liked = (previous_swipe or {}).get("action") == "like"
        if not was_already_liked:
            await db.users.update_one({"id": body.target_user_id}, {"$inc": {"popularity_score": 1}})
        reciprocal = await db.swipes.find_one({"user_id": body.target_user_id, "target_user_id": user["id"], "action": "like"})
        if reciprocal:
            existing = await db.matches.find_one({"users": {"$all": [user["id"], body.target_user_id]}})
            if existing:
                return {"match": True, "match_id": existing["id"]}
            match = {"id": str(uuid.uuid4()), "users": [user["id"], body.target_user_id], "created_at": now_iso(), "last_message_at": None}
            await db.matches.insert_one(match)
            # Notify both users — push lands even when the app is in the background
            matcher_name = user.get("name", "Someone")
            target_name = target.get("name", "Someone")
            await send_push_notification(
                body.target_user_id,
                title="It's a match 💛",
                body=f"You and {matcher_name} liked each other!",
                data={"type": "match", "match_id": match["id"]},
            )
            await send_push_notification(
                user["id"],
                title="It's a match 💛",
                body=f"You and {target_name} liked each other!",
                data={"type": "match", "match_id": match["id"]},
            )
            return {"match": True, "match_id": match["id"]}
    return {"match": False}

@app.get("/api/matches")
async def get_matches(
    user: dict = Depends(get_current_user),
    limit: int = 50,
    before: Optional[str] = None,
):
    """Return up to `limit` matches (max 200), newest-first.

    Pass `before=<created_at ISO string>` to paginate to older matches.
    """
    limit = max(1, min(limit, 200))
    query: dict = {"users": user["id"]}
    if before:
        query["created_at"] = {"$lt": before}
    matches = await db.matches.find(query, {"_id": 0}).sort("created_at", -1).limit(limit).to_list(limit)
    other_ids = [uid for m in matches for uid in m["users"] if uid != user["id"]]
    people = await db.users.find(
        {"id": {"$in": list(set(other_ids))}},
        {"_id": 0, "id": 1, "name": 1, "photo_url": 1, "city": 1},
    ).to_list(len(other_ids) or 1)
    person_map = {p["id"]: p for p in people}
    for m in matches:
        other_id = next((uid for uid in m["users"] if uid != user["id"]), None)
        m["user"] = person_map.get(other_id)
    return {"matches": matches, "has_more": len(matches) == limit}

class ConnectionManager:
    def __init__(self):
        self.active: Dict[str, List[WebSocket]] = {}

    async def connect(self, user_id: str, websocket: WebSocket):
        self.active.setdefault(user_id, []).append(websocket)

    def disconnect(self, user_id: str, websocket: WebSocket):
        sockets = self.active.get(user_id, [])
        if websocket in sockets:
            sockets.remove(websocket)
        if not sockets:
            self.active.pop(user_id, None)

    async def send_to_user(self, user_id: str, payload: dict):
        for ws in self.active.get(user_id, [])[:]:
            try:
                await ws.send_json(payload)
            except Exception:
                self.disconnect(user_id, ws)

manager = ConnectionManager()

# ---------------------------------------------------------------------------
# Redis Pub/Sub fanout — required for multi-container deployments.
# Each container subscribes to "ws_events" and delivers messages to its own
# locally-connected WebSocket clients.  Single-instance deployments work fine
# too: the local manager.send_to_user call still runs as a subscriber.
# ---------------------------------------------------------------------------
WS_PUBSUB_CHANNEL = "ws_events"

async def _redis_pubsub_listener():
    """Background task: subscribe to Redis and fan out to local WS clients.

    The listener reconnects with backoff instead of crashing once when Redis is
    unavailable. That keeps local WebSocket delivery alive and avoids noisy CPU
    spin during development or infrastructure restarts.
    """
    import json as _json
    import asyncio as _asyncio
    if not redis_client:
        logger.warning("Redis unavailable — WebSocket fanout limited to single instance")
        return
    backoff = 1
    while True:
        pubsub = None
        try:
            pubsub = redis_client.pubsub()
            await _redis_run(pubsub.subscribe, WS_PUBSUB_CHANNEL)
            loop = _asyncio.get_running_loop()
            backoff = 1
            while True:
                raw = await loop.run_in_executor(None, pubsub.get_message, True, 1.0)
                if raw and raw.get("type") == "message":
                    try:
                        envelope = _json.loads(raw.get("data") or "{}")
                        uid = envelope.get("user_id")
                        payload = envelope.get("payload")
                        if uid and payload:
                            await manager.send_to_user(uid, payload)
                    except Exception as exc:
                        logger.warning(
                            "WS pubsub decode error (data=%s): %s",
                            str(raw.get("data", ""))[:120],
                            exc,
                        )
                await _asyncio.sleep(0.05)
        except _asyncio.CancelledError:
            if pubsub:
                try:
                    await _redis_run(pubsub.close)
                except Exception:
                    pass
            raise
        except Exception as exc:
            logger.warning("WS pubsub listener unavailable; retrying in %ss: %s", backoff, exc)
            if pubsub:
                try:
                    await _redis_run(pubsub.close)
                except Exception:
                    pass
            await _asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30)

async def publish_ws_event(user_id: str, payload: dict):
    """Publish to Redis so every container can fan out; also deliver locally."""
    import json as _json
    import asyncio as _asyncio
    if redis_client:
        try:
            envelope = _json.dumps({"user_id": user_id, "payload": payload}, default=str)
            loop = _asyncio.get_running_loop()
            await loop.run_in_executor(None, redis_client.publish, WS_PUBSUB_CHANNEL, envelope)
            # The subscriber running in this same process will call manager.send_to_user
            return
        except Exception as exc:
            logger.warning("Redis publish failed, falling back to local delivery: %s", exc)
    # Fallback: Redis unavailable — deliver directly to local connections only
    await manager.send_to_user(user_id, payload)

@app.post("/api/messages")
async def send_message(body: MessageRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "messages", 60, 300, actor_id=user["id"])
    await ensure_match_member(body.match_id, user["id"])
    text = body.text.strip()
    if not text:
        raise HTTPException(400, "Message cannot be empty")
    if len(text) > 2000:
        await audit_event("message_rejected", request=request, user_id=user["id"], severity="warning", reason="too_long", match_id=body.match_id)
        raise HTTPException(400, "Message too long")
    flags = basic_content_flags(text)
    provider_result = await external_moderation("message", {"text": text, "user_id": user["id"], "match_id": body.match_id})
    flags.extend([f"provider:{f}" for f in provider_result.get("flags", [])])
    if any(flag.startswith("blocked_pattern:") for flag in flags) or provider_result.get("approved") is False:
        await audit_event("message_rejected", request=request, user_id=user["id"], severity="warning", reason="moderation_block", flags=flags, match_id=body.match_id)
        raise HTTPException(400, "Message could not be sent.")
    moderation_status = "flagged" if flags else "approved"
    if flags:
        await audit_event("message_flagged", request=request, user_id=user["id"], severity="warning", flags=flags, match_id=body.match_id)
    message = {"id": str(uuid.uuid4()), "match_id": body.match_id, "sender_id": user["id"], "text": text, "type": "text", "created_at": now_iso(), "read_by": [user["id"]], "moderation_status": moderation_status, "moderation_flags": flags}
    await db.messages.insert_one(message)
    if flags:
        await create_moderation_job("message", user["id"], {"message_id": message["id"], "match_id": body.match_id, "flags": flags}, priority=80)
    await db.matches.update_one({"id": body.match_id}, {"$set": {"last_message_at": now_iso()}})
    match = await db.matches.find_one({"id": body.match_id})
    public_message = dict(message); public_message.pop("_id", None)
    sender_name = user.get("name", "Someone")
    for recipient_id in [uid for uid in match["users"] if uid != user["id"]]:
        await publish_ws_event(recipient_id, {"type": "message", "message": public_message})
        # Push delivers the message even when the recipient's app is closed
        await send_push_notification(
            recipient_id,
            title=sender_name,
            body=text[:100] + ("…" if len(text) > 100 else ""),
            data={"type": "message", "match_id": body.match_id},
        )
    return public_message

@app.get("/api/messages/{match_id}")
async def get_messages(
    match_id: str,
    user: dict = Depends(get_current_user),
    limit: int = 50,
    before: Optional[str] = None,
):
    """Return up to `limit` messages (max 100), newest-first, with cursor-based pagination.

    Pass `before=<created_at ISO string>` to fetch the page before that timestamp.
    The client should reverse the list for display order (oldest→newest).
    """
    await ensure_match_member(match_id, user["id"])
    limit = max(1, min(limit, 100))
    query: dict = {"match_id": match_id}
    if before:
        query["created_at"] = {"$lt": before}
    messages = (
        await db.messages.find(query, {"_id": 0})
        .sort("created_at", -1)
        .limit(limit)
        .to_list(limit)
    )
    # Return in ascending order so the client can append naturally
    messages.reverse()
    return messages

@app.websocket("/api/ws")
async def websocket_endpoint(websocket: WebSocket):
    # Clients connect to /api/ws, then immediately send {"type":"auth","token":"..."}.
    # This keeps JWTs out of query strings, server logs, CDN logs, and proxy logs.

    # --- Rate-limit auth attempts per IP BEFORE accepting the connection ---
    ip = _client_ip(websocket=websocket)
    if redis_client:
        try:
            ws_auth_key = f"rate:ws_connect:ip:{ip}"
            pipe = redis_client.pipeline()
            pipe.incr(ws_auth_key)
            pipe.ttl(ws_auth_key)
            count, ttl_remaining = await _redis_run(pipe.execute)
            if ttl_remaining < 0:
                await _redis_run(redis_client.expire, ws_auth_key, 60)
            if count > int(os.getenv("WS_AUTH_RATE_LIMIT", "20")):
                security_log("ws_auth_rate_limited", ip=ip, count=count)
                await metric_incr("ws_auth_rate_limit_hits")
                await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
                return
        except Exception as exc:
            logger.warning("WS auth rate limiter failed: %s", exc)

    await websocket.accept()
    user_id = None
    try:
        auth_msg = await _asyncio.wait_for(websocket.receive_json(), timeout=5)
        token = (auth_msg or {}).get("token") if (auth_msg or {}).get("type") == "auth" else None
        if not token:
            security_log("ws_auth_failure", reason="missing_initial_auth", ip=_client_ip(websocket=websocket))
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            security_log("ws_auth_failure", reason="wrong_token_type", ip=_client_ip(websocket=websocket))
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return
        user_id = payload["sub"]
        user = await db.users.find_one({"id": user_id, "banned": {"$ne": True}, "deleted": {"$ne": True}, "shadowbanned": {"$ne": True}})
        if not user or int(payload.get("token_version", -1)) != int(user.get("token_version", 0)):
            security_log("ws_auth_failure", reason="revoked_or_missing_user", user_id=user_id, ip=_client_ip(websocket=websocket))
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return
    except jwt.ExpiredSignatureError:
        security_log("ws_auth_failure", reason="token_expired", ip=_client_ip(websocket=websocket))
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return
    except jwt.InvalidTokenError:
        security_log("ws_auth_failure", reason="invalid_token", ip=_client_ip(websocket=websocket))
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return
    except _asyncio.TimeoutError:
        security_log("ws_auth_failure", reason="auth_timeout", ip=_client_ip(websocket=websocket))
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return
    except Exception as exc:
        security_log("ws_auth_failure", reason="unexpected", error=str(exc)[:120], ip=_client_ip(websocket=websocket))
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION); return

    await manager.connect(user_id, websocket)
    try:
        while True:
            msg = await websocket.receive_json()
            # Generic event-level rate limit (covers all message types)
            if not await ws_rate_limit(user_id, "events", 60, 60):
                await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
                return
            # Do not allow clients to swap/re-authenticate a socket after the
            # initial authenticated identity has been established.
            if (msg or {}).get("type") == "auth":
                security_log("ws_reauth_attempt", user_id=user_id, ip=_client_ip(websocket=websocket))
                await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
                return
            # Per-message-type rate limit for any future typed client events
            msg_type = (msg or {}).get("type", "unknown")
            if not await ws_rate_limit(user_id, f"msg:{msg_type}", 30, 60):
                security_log("ws_msg_rate_limit", user_id=user_id, msg_type=msg_type, ip=_client_ip(websocket=websocket))
                await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
                return
            # Reserved for lightweight future client events such as typing/read receipts.
    except WebSocketDisconnect:
        manager.disconnect(user_id, websocket)
    except Exception as exc:
        logger.info("WS closed for user=%s: %s", user_id, exc)
        manager.disconnect(user_id, websocket)

@app.get("/api/likes")
async def likes(user: dict = Depends(get_current_user)):
    count = await db.swipes.count_documents({"target_user_id": user["id"], "action": "like"})
    if not user.get("is_gold"):
        return {"blurred": True, "count": count}
    docs = await db.swipes.find({"target_user_id": user["id"], "action": "like"}, {"_id": 0, "user_id": 1}).to_list(100)
    users = await db.users.find({"id": {"$in": [d["user_id"] for d in docs]}}, {"_id": 0, "id": 1, "name": 1, "age": 1, "photo_url": 1, "city": 1}).to_list(100)
    return {"blurred": False, "users": users}

@app.post("/api/boost")
async def boost(request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "boost", 10, 3600, actor_id=user["id"])
    if not user.get("is_gold"):
        raise HTTPException(402, "Upgrade to Gold to boost your profile")
    boost_until = datetime.now(timezone.utc).timestamp() + 3600
    await db.users.update_one({"id": user["id"]}, {"$set": {"boost_until": boost_until}})
    return {"boost": True, "boost_until": boost_until}

@app.get("/api/heatmap")
async def heatmap(user: dict = Depends(get_current_user)):
    totals = await db.users.aggregate([{"$match": {"onboarded": True, "banned": {"$ne": True}, "deleted": {"$ne": True}, "shadowbanned": {"$ne": True}, "city": {"$ne": None}}}, {"$group": {"_id": "$city", "count": {"$sum": 1}}}]).to_list(1000)
    return {"cities": [{"city": row["_id"], "total": row["count"]} for row in totals]}

@app.post("/api/translate")
async def translate(body: TranslateRequest, request: Request, user: dict = Depends(get_current_user)):
    """Translate text using LibreTranslate (if configured) with MyMemory as a zero-config fallback.

    Configure LibreTranslate:
      LIBRETRANSLATE_URL=https://libretranslate.com   (or your self-hosted instance)
      LIBRETRANSLATE_API_KEY=<your-key>               (required for libretranslate.com, optional for self-hosted)

    MyMemory is used automatically as a fallback when LibreTranslate is not configured.
    It supports ~2000 free words/day per IP.  Set MYMEMORY_EMAIL for a higher free quota.
    """
    await rate_limit(request, "translate", 30, 300, actor_id=user["id"])
    text = body.text.strip()
    if not text:
        raise HTTPException(400, "Text is required")
    if len(text) > 5000:
        raise HTTPException(400, "Text must be 5000 characters or fewer")

    import asyncio as _asyncio
    import httpx

    libretranslate_url = os.getenv("LIBRETRANSLATE_URL", "").rstrip("/")
    libretranslate_key = os.getenv("LIBRETRANSLATE_API_KEY", "")

    # --- LibreTranslate (preferred) ---
    if libretranslate_url:
        payload: dict = {
            "q": text,
            "source": body.source_language or "auto",
            "target": body.target_language,
            "format": "text",
        }
        if libretranslate_key:
            payload["api_key"] = libretranslate_key
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(f"{libretranslate_url}/translate", json=payload)
            if resp.status_code == 200:
                result = resp.json()
                translated = result.get("translatedText") or result.get("translated_text")
                if translated:
                    await metric_incr("translations_libretranslate")
                    return {
                        "translated_text": translated,
                        "target_language": body.target_language,
                        "source_language": result.get("detectedLanguage", {}).get("language") or body.source_language,
                        "provider": "libretranslate",
                    }
            logger.warning("LibreTranslate non-200: %s %s", resp.status_code, resp.text[:200])
        except Exception as exc:
            logger.warning("LibreTranslate unavailable, falling back to MyMemory: %s", exc)

    # --- MyMemory fallback (no configuration required) ---
    try:
        source_lang = body.source_language or "autodetect"
        lang_pair = f"{source_lang}|{body.target_language}"
        params: dict = {"q": text, "langpair": lang_pair}
        mymemory_email = os.getenv("MYMEMORY_EMAIL", "")
        if mymemory_email:
            params["de"] = mymemory_email
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get("https://api.mymemory.translated.net/get", params=params)
        if resp.status_code == 200:
            data = resp.json()
            translated = (data.get("responseData") or {}).get("translatedText")
            if translated and data.get("responseStatus") == 200:
                await metric_incr("translations_mymemory")
                return {
                    "translated_text": translated,
                    "target_language": body.target_language,
                    "source_language": body.source_language,
                    "provider": "mymemory",
                }
            logger.warning("MyMemory bad response: %s", data.get("responseStatus"))
    except Exception as exc:
        logger.error("MyMemory translation failed: %s", exc)

    raise HTTPException(503, "Translation service is temporarily unavailable. Please try again.")

@app.post("/api/report")
async def report_user(body: ReportRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "report", 5, 300, actor_id=user["id"])
    if body.target_user_id == user["id"]:
        raise HTTPException(400, "You cannot report yourself")
    if not body.reason.strip():
        raise HTTPException(400, "Report reason is required")
    target = await db.users.find_one({"id": body.target_user_id})
    if not target:
        raise HTTPException(404, "User not found")
    report = {"id": str(uuid.uuid4()), "reporter_id": user["id"], "target_user_id": body.target_user_id, "reason": body.reason.strip()[:1000], "created_at": now_iso(), "resolved": False}
    await db.reports.insert_one(report)
    report_count = await db.reports.count_documents({"target_user_id": body.target_user_id, "resolved": False})
    await db.users.update_one({"id": body.target_user_id}, {"$set": {"open_report_count": report_count}})
    await create_moderation_job("report", body.target_user_id, {"report_id": report["id"], "reporter_id": user["id"], "reason": report["reason"], "open_report_count": report_count}, priority=90 if report_count >= 3 else 60)
    if report_count >= int(os.getenv("AUTO_SHADOWBAN_REPORT_THRESHOLD", "5")):
        await db.users.update_one({"id": body.target_user_id}, {"$set": {"shadowbanned": True, "shadowbanned_at": now_iso()}})
        await audit_event("user_auto_shadowbanned", request=request, user_id=body.target_user_id, severity="critical", open_report_count=report_count)
    await audit_event("user_reported", request=request, user_id=user["id"], severity="warning", target_user_id=body.target_user_id, open_report_count=report_count)
    report.pop("_id", None)
    return {"message": "Report submitted.", "report": report}

@app.post("/api/block")
async def block_user(body: BlockRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "block", 30, 300, actor_id=user["id"])
    if body.target_user_id == user["id"]:
        raise HTTPException(400, "You cannot block yourself")
    # Write to dedicated blocks collection — avoids growing an unbounded inline
    # array on the user document (heavy blockers could cause the document to
    # exceed MongoDB's 16 MB limit and slow all queries on that document).
    await db.blocks.update_one(
        {"blocker_id": user["id"], "blocked_id": body.target_user_id},
        {"$setOnInsert": {"blocker_id": user["id"], "blocked_id": body.target_user_id, "created_at": now_iso()}},
        upsert=True,
    )
    # Invalidate discover cache so the blocked user is excluded on the next load
    await cache_delete(_discover_cache_key(user))
    # Close any existing matches between the two users so neither can send messages
    # after a block. We soft-delete by marking blocked=True rather than removing
    # the document, preserving message history for moderation if needed.
    await db.matches.update_many(
        {"users": {"$all": [user["id"], body.target_user_id]}},
        {"$set": {"blocked": True, "blocked_by": user["id"], "blocked_at": now_iso()}},
    )
    return {"blocked": True, "target_user_id": body.target_user_id}

@app.post("/api/stripe/create-checkout-session")
async def create_checkout_session(request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "checkout", 10, 3600, actor_id=user["id"])
    if not STRIPE_ENABLED:
        return {"disabled": True, "message": "Payments are currently disabled."}
    if not STRIPE_SECRET_KEY or not STRIPE_PRICE_GOLD:
        raise HTTPException(503, "Stripe is not configured")
    customer_id = user.get("stripe_customer_id")
    loop = _asyncio.get_running_loop()
    if not customer_id:
        customer = await loop.run_in_executor(
            None,
            lambda: stripe.Customer.create(email=user["email"], metadata={"user_id": user["id"]}),
        )
        customer_id = customer.id
        await db.users.update_one({"id": user["id"]}, {"$set": {"stripe_customer_id": customer_id}})
    session = await loop.run_in_executor(
        None,
        lambda: stripe.checkout.Session.create(
            customer=customer_id,
            mode="subscription",
            line_items=[{"price": STRIPE_PRICE_GOLD, "quantity": 1}],
            success_url=f"{APP_BASE_URL}/payment-success",
            cancel_url=f"{APP_BASE_URL}/payment-cancelled",
            metadata={"user_id": user["id"]},
        ),
    )
    return {"url": session.url}


# ---------------------------------------------------------------------------
# Photo upload — returns a pre-signed PUT URL (or accepts direct upload)
# ---------------------------------------------------------------------------
from fastapi import UploadFile, File

def _scan_for_malware(data: bytes) -> None:
    """Run ClamAV scan if CLAMD_SCAN_PATH is set.

    In production without ClamAV configured, logs a prominent warning and
    continues — photo re-encoding + external moderation still run.  Set
    CLAMD_SCAN_PATH (e.g. /usr/bin/clamscan) to enable full AV scanning.
    """
    scan_path = os.getenv("CLAMD_SCAN_PATH", "").strip()
    if not scan_path:
        if os.getenv("ASA_ENV", "development") == "production":
            logger.warning(
                "security_gap: CLAMD_SCAN_PATH not set in production — "
                "photo uploads are not AV-scanned. Set CLAMD_SCAN_PATH to enable."
            )
        return
    try:
        proc = subprocess.run(
            [scan_path, "--no-summary", "-"],
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
        )
        if proc.returncode != 0:
            logger.warning("Photo malware scan flagged upload: %s %s", proc.stdout[:200], proc.stderr[:200])
            raise HTTPException(400, "Photo failed security scan")
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Photo malware scanner unavailable: %s", exc)
        raise HTTPException(503, "Photo security scanner unavailable")

def _validate_and_reencode_image(data: bytes, content_type: str) -> bytes:
    """Decode and re-encode the image to strip polyglot/trailing payloads and metadata."""
    try:
        from PIL import Image, ImageOps
    except Exception:
        raise HTTPException(503, "Image validation library is not installed")
    try:
        with Image.open(io.BytesIO(data)) as img:
            img.verify()
        with Image.open(io.BytesIO(data)) as img:
            img = ImageOps.exif_transpose(img)
            if img.width < 200 or img.height < 200:
                security_log("upload_rejected", reason="too_small", width=img.width, height=img.height)
                raise HTTPException(400, "Photo is too small")
            if img.width * img.height > MAX_PHOTO_PIXELS:
                security_log("upload_rejected", reason="dimensions_too_large", width=img.width, height=img.height, pixels=img.width * img.height)
                raise HTTPException(400, "Photo dimensions are too large")
            if content_type == "image/jpeg" and (img.info.get("progressive") or img.info.get("progression")):
                security_log("upload_rejected", reason="progressive_jpeg", width=img.width, height=img.height)
                raise HTTPException(400, "Progressive JPEGs are not accepted")
            fmt = {"image/jpeg": "JPEG", "image/png": "PNG", "image/webp": "WEBP"}[content_type]
            if fmt == "JPEG" and img.mode not in ("RGB", "L"):
                img = img.convert("RGB")
            out = io.BytesIO()
            save_kwargs = {"format": fmt}
            if fmt == "JPEG":
                save_kwargs.update({"quality": 90, "optimize": True})
            img.save(out, **save_kwargs)
            return out.getvalue()
    except HTTPException:
        raise
    except Exception as exc:
        security_log("upload_rejected", reason="decode_or_reencode_failed", error=str(exc)[:120])
        raise HTTPException(400, "Invalid or unsafe image file")

@app.post("/api/profile/photo")
async def upload_photo(
    request: Request,
    file: UploadFile = File(...),
    user: dict = Depends(get_current_user),
):
    await rate_limit(request, "photo-upload", 12, 3600, actor_id=user["id"])
    if not STORAGE_ENABLED:
        raise HTTPException(503, "Photo storage is not configured on this server.")
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        security_log("upload_rejected", reason="unsupported_type", user_id=user["id"], content_type=file.content_type)
        await metric_incr("upload_rejections")
        await audit_event("upload_rejected", request=request, user_id=user["id"], severity="warning", reason="unsupported_type", content_type=file.content_type)
        raise HTTPException(400, f"Unsupported image type: {file.content_type}. Use JPEG, PNG, or WebP.")
    data = await file.read(MAX_PHOTO_BYTES + 1)
    if len(data) > MAX_PHOTO_BYTES:
        security_log("upload_rejected", reason="file_too_large", user_id=user["id"], bytes=len(data), max_bytes=MAX_PHOTO_BYTES)
        await metric_incr("upload_rejections")
        await audit_event("upload_rejected", request=request, user_id=user["id"], severity="warning", reason="file_too_large", bytes=len(data), max_bytes=MAX_PHOTO_BYTES)
        raise HTTPException(413, f"Photo must be under {MAX_PHOTO_BYTES // (1024 * 1024)} MB.")
    _scan_for_malware(data)
    data = _validate_and_reencode_image(data, file.content_type)
    ext = file.content_type.split("/")[-1].replace("jpeg", "jpg")
    key = f"photos/{user['id']}/{uuid.uuid4().hex}.{ext}"
    loop = _asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: s3_client.put_object(
                Bucket=STORAGE_BUCKET,
                Key=key,
                Body=data,
                ContentType=file.content_type,
                CacheControl="public, max-age=31536000",
            ),
        )
    except Exception as exc:
        logger.error("S3 upload failed: %s", exc)
        raise HTTPException(502, "Photo upload failed. Please try again.")
    photo_url = f"{STORAGE_PUBLIC_BASE_URL}/{key}" if STORAGE_PUBLIC_BASE_URL else f"https://{STORAGE_BUCKET}.s3.amazonaws.com/{key}"
    provider_result = await external_moderation("photo", {"photo_url": photo_url, "storage_key": key, "user_id": user["id"]})
    photo_status = "pending" if provider_result.get("approved", True) else "flagged"
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"photo_url": photo_url, "photo_moderation_status": photo_status, "photo_uploaded_at": now_iso(), "photo_moderation_flags": provider_result.get("flags", [])}},
    )
    await create_moderation_job("photo", user["id"], {"photo_url": photo_url, "storage_key": key, "provider_result": provider_result}, priority=95 if photo_status == "flagged" else 70)
    await audit_event("photo_uploaded_for_moderation", request=request, user_id=user["id"], severity="info", storage_key=key)
    return {"photo_url": photo_url, "moderation_status": "pending"}


@app.get("/api/profile/photo/upload-url")
async def get_photo_upload_url(
    request: Request,
    content_type: str = "image/jpeg",
    user: dict = Depends(get_current_user),
):
    """Alternative: returns a pre-signed URL so the client uploads directly to S3/R2."""
    await rate_limit(request, "photo-upload-url", 12, 3600, actor_id=user["id"])
    if not PHOTO_DIRECT_UPLOAD_ENABLED:
        raise HTTPException(403, "Direct-to-storage photo uploads are disabled; use /api/profile/photo so files can be scanned.")
    if not STORAGE_ENABLED:
        raise HTTPException(503, "Photo storage is not configured on this server.")
    if content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(400, f"Unsupported image type. Use: {', '.join(ALLOWED_IMAGE_TYPES)}")
    ext = content_type.split("/")[-1].replace("jpeg", "jpg")
    key = f"photos/{user['id']}/{uuid.uuid4().hex}.{ext}"
    loop = _asyncio.get_running_loop()
    url = await loop.run_in_executor(
        None,
        lambda: s3_client.generate_presigned_url(
            "put_object",
            Params={"Bucket": STORAGE_BUCKET, "Key": key, "ContentType": content_type},
            ExpiresIn=300,
        ),
    )
    photo_url = f"{STORAGE_PUBLIC_BASE_URL}/{key}" if STORAGE_PUBLIC_BASE_URL else f"https://{STORAGE_BUCKET}.s3.amazonaws.com/{key}"
    return {"upload_url": url, "photo_url": photo_url, "key": key}


@app.post("/api/profile/photo/confirm")
async def confirm_photo_upload(
    body: dict,
    request: Request,
    user: dict = Depends(get_current_user),
):
    """Call after a successful pre-signed upload to persist the photo_url on the profile."""
    await rate_limit(request, "photo-confirm", 12, 3600, actor_id=user["id"])
    if not PHOTO_DIRECT_UPLOAD_ENABLED:
        raise HTTPException(403, "Direct-to-storage photo uploads are disabled; use /api/profile/photo so files can be scanned.")
    # STORAGE_PUBLIC_BASE_URL is required when direct upload is enabled.
    # Without it we cannot verify the URL belongs to our own bucket, which
    # would allow users to set arbitrary external URLs as their profile photo.
    if not STORAGE_PUBLIC_BASE_URL:
        logger.error("confirm_photo_upload called but STORAGE_PUBLIC_BASE_URL is not configured")
        raise HTTPException(503, "Photo upload confirmation is misconfigured on the server.")
    photo_url = (body.get("photo_url") or "").strip()
    if not photo_url or not photo_url.startswith("https://"):
        raise HTTPException(400, "Invalid photo_url")
    # Strictly enforce that the URL belongs to our own storage bucket.
    if not photo_url.startswith(STORAGE_PUBLIC_BASE_URL):
        security_log("upload_rejected", reason="foreign_photo_url", user_id=user["id"], photo_url=photo_url[:200])
        await audit_event("upload_rejected", request=request, user_id=user["id"], severity="warning", reason="foreign_photo_url")
        raise HTTPException(400, "Invalid photo_url")
    await db.users.update_one({"id": user["id"]}, {"$set": {"photo_url": photo_url}})
    return {"photo_url": photo_url}


# ---------------------------------------------------------------------------
# Stripe webhook — verified + handles subscription lifecycle
# ---------------------------------------------------------------------------

@app.post("/api/stripe/webhook")
async def stripe_webhook(request: Request):
    if not STRIPE_ENABLED:
        return {"ignored": True}
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")
    if not STRIPE_WEBHOOK_SECRET:
        raise HTTPException(503, "Stripe webhook secret is not configured.")
    loop = _asyncio.get_running_loop()
    # Build a tuple of signature-verification error classes that works across
    # stripe-python v4 (stripe.error.SignatureVerificationError) and
    # stripe-python v5+ (stripe.SignatureVerificationError).
    _stripe_sig_exc_classes: tuple = ()
    if hasattr(stripe, "SignatureVerificationError"):
        _stripe_sig_exc_classes += (stripe.SignatureVerificationError,)
    if hasattr(stripe, "error") and hasattr(stripe.error, "SignatureVerificationError"):
        _stripe_sig_exc_classes += (stripe.error.SignatureVerificationError,)
    if not _stripe_sig_exc_classes:
        _stripe_sig_exc_classes = (Exception,)  # safe fallback

    try:
        event = await loop.run_in_executor(
            None,
            lambda: stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET),
        )
    except tuple(_stripe_sig_exc_classes):
        logger.warning("Stripe webhook signature verification failed")
        raise HTTPException(400, "Invalid webhook signature")
    except Exception as exc:
        logger.error("Stripe webhook parse error: %s", exc)
        raise HTTPException(400, "Webhook parse error")

    etype = event["type"]
    logger.info("Stripe event received: %s", etype)

    if etype == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = (session.get("metadata") or {}).get("user_id")
        customer_id = session.get("customer")
        subscription_id = session.get("subscription")
        if user_id:
            await db.users.update_one(
                {"id": user_id},
                {"$set": {
                    "is_gold": True,
                    "stripe_customer_id": customer_id,
                    "stripe_subscription_id": subscription_id,
                    "gold_since": now_iso(),
                }},
            )
            logger.info("User %s upgraded to Gold (subscription %s)", user_id, subscription_id)

    elif etype in ("customer.subscription.deleted", "customer.subscription.paused"):
        sub = event["data"]["object"]
        customer_id = sub.get("customer")
        await db.users.update_one(
            {"stripe_customer_id": customer_id},
            {"$set": {"is_gold": False, "stripe_subscription_id": None}},
        )
        logger.info("Gold revoked for Stripe customer %s (event: %s)", customer_id, etype)

    elif etype == "customer.subscription.updated":
        sub = event["data"]["object"]
        customer_id = sub.get("customer")
        is_active = sub.get("status") == "active"
        await db.users.update_one(
            {"stripe_customer_id": customer_id},
            {"$set": {"is_gold": is_active}},
        )

    elif etype == "invoice.payment_failed":
        invoice = event["data"]["object"]
        customer_id = invoice.get("customer")
        logger.warning("Payment failed for Stripe customer %s", customer_id)
        # Optionally: send an email here, set a grace-period flag, etc.

    return {"received": True}


# ---------------------------------------------------------------------------
# Push notifications — Expo Push Notification Service (EPNS).
# No SDK required: we POST directly to Expo's push API.
# Users register their Expo push token after login; it is stored on their
# profile.  send_push_notification() is called for new matches and messages.
# ---------------------------------------------------------------------------
EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send"

async def send_push_notification(user_id: str, title: str, body: str, data: dict = None) -> None:
    """Fire-and-forget push to a user's registered Expo push token.

    Errors are logged with structured fields so they surface in admin metrics
    rather than being silently swallowed.
    """
    import httpx
    target = await db.users.find_one({"id": user_id}, {"push_token": 1})
    if not target:
        return
    token = (target.get("push_token") or "").strip()
    if not token or not (token.startswith("ExponentPushToken[") and token.endswith("]")):
        return
    message = {"to": token, "title": title, "body": body, "sound": "default"}
    if data:
        message["data"] = data
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.post(
                EXPO_PUSH_URL,
                json=message,
                headers={
                    "Accept": "application/json",
                    "Accept-Encoding": "gzip, deflate",
                    "Content-Type": "application/json",
                },
            )
            result = resp.json()
            if resp.status_code != 200:
                logger.warning(
                    "Expo push non-200 for user=%s status=%s body=%s",
                    user_id, resp.status_code, str(result)[:200],
                )
                await metric_incr("push_delivery_errors")
            else:
                ticket = (result.get("data") or {})
                ticket_status = ticket.get("status")
                if ticket_status and ticket_status != "ok":
                    err_type = ticket.get("details", {}).get("error", "unknown")
                    logger.warning(
                        "Expo push ticket error for user=%s status=%s error=%s",
                        user_id, ticket_status, err_type,
                    )
                    await metric_incr("push_delivery_errors")
                    # DeviceNotRegistered: clear the stale token so we stop wasting calls
                    if err_type == "DeviceNotRegistered":
                        await db.users.update_one(
                            {"id": user_id},
                            {"$unset": {"push_token": ""}, "$set": {"updated_at": now_iso()}},
                        )
                        logger.info("Cleared stale push token for user=%s", user_id)
                else:
                    await metric_incr("push_delivered")
    except Exception as exc:
        logger.warning("Push notification failed for user=%s: %s", user_id, exc)
        await metric_incr("push_delivery_errors")


@app.post("/api/push/register")
async def register_push_token(body: PushTokenRequest, request: Request, user: dict = Depends(get_current_user)):
    await rate_limit(request, "push-token", 20, 3600, actor_id=user["id"])
    token = (body.token or "").strip()
    if not token:
        raise HTTPException(400, "Push token is required")
    await db.users.update_one({"id": user["id"]}, {"$set": {"push_token": token, "updated_at": now_iso()}})
    return {"registered": True}


# ---------------------------------------------------------------------------
# Email delivery — Resend (primary) or SMTP (fallback).
# Priority: if RESEND_API_KEY is set, use Resend's HTTP API (no extra deps).
# Otherwise fall back to SMTP (SendGrid, Postmark, SES, etc.).
# If neither is configured, logs the email body so dev flows still work.
# ---------------------------------------------------------------------------
RESEND_API_KEY = os.getenv("RESEND_API_KEY", "")
RESEND_FROM = os.getenv("RESEND_FROM", "")  # e.g. "Obi <noreply@yourdomain.com>"

SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
SMTP_FROM = os.getenv("SMTP_FROM", "noreply@yourdomain.com")

EMAIL_ENABLED = bool(RESEND_API_KEY or (SMTP_HOST and SMTP_USER and SMTP_PASS))


async def send_email(to: str, subject: str, body_text: str) -> None:
    """Send a plain-text email via Resend (preferred) or SMTP (fallback).

    Resend setup (recommended — no extra dependencies):
      RESEND_API_KEY=re_...
      RESEND_FROM=Obi <noreply@yourdomain.com>

    SMTP setup (any provider):
      SMTP_HOST=smtp.sendgrid.net  SMTP_PORT=587
      SMTP_USER=apikey  SMTP_PASS=<key>  SMTP_FROM=noreply@yourdomain.com
    """
    import asyncio as _asyncio

    # --- Resend (HTTP API, no extra deps) ---
    if RESEND_API_KEY:
        import httpx
        from_addr = RESEND_FROM or f"Obi <noreply@{APP_BASE_URL.replace('https://', '').replace('http://', '')}>"
        payload = {"from": from_addr, "to": [to], "subject": subject, "text": body_text}
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(
                    "https://api.resend.com/emails",
                    json=payload,
                    headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
                )
            if resp.status_code in (200, 201):
                logger.info("Email sent via Resend to %s | %s", to, subject)
                return
            logger.error("Resend error %s: %s", resp.status_code, resp.text[:300])
            # Fall through to SMTP if Resend fails
        except Exception as exc:
            logger.error("Resend unavailable, trying SMTP: %s", exc)

    # --- SMTP fallback ---
    if SMTP_HOST and SMTP_USER and SMTP_PASS:
        import smtplib
        from email.mime.text import MIMEText
        msg = MIMEText(body_text, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = SMTP_FROM
        msg["To"] = to

        def _send():
            with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as server:
                server.ehlo()
                server.starttls()
                server.login(SMTP_USER, SMTP_PASS)
                server.sendmail(SMTP_FROM, [to], msg.as_string())

        try:
            loop = _asyncio.get_running_loop()
            await loop.run_in_executor(None, _send)
            logger.info("Email sent via SMTP to %s | %s", to, subject)
            return
        except Exception as exc:
            logger.error("SMTP delivery failed to %s: %s", to, exc)
            return

    # --- No provider configured (dev mode) ---
    logger.warning(
        "No email provider configured — email NOT sent to %s | Subject: %s | Body preview: %.200s",
        to, subject, body_text,
    )


@app.post("/api/auth/request-account-deletion")
async def request_account_deletion(body: AccountDeletionRequest, request: Request):
    await rate_limit(request, "account-deletion", 5, 3600)
    email = body.email.lower().strip()
    target = await db.users.find_one({"email": email})
    if target:
        token = uuid.uuid4().hex + uuid.uuid4().hex
        await db.account_deletions.insert_one({
            "id": str(uuid.uuid4()),
            "user_id": target["id"],
            "email": email,
            "token": token,
            "created_at": now_iso(),
            "expires_at": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
            "used": False,
        })
        deletion_url = f"{APP_BASE_URL}/confirm-delete?token={token}"
        await send_email(
            to=email,
            subject="Confirm your Obi account deletion",
            body_text=(
                f"Hi {target.get('name', 'there')},\n\n"
                "We received a request to permanently delete your Obi account.\n\n"
                f"Click the link below to confirm (link expires in 1 hour):\n{deletion_url}\n\n"
                "If you did not request this, you can safely ignore this email.\n\n"
                "— The Obi Team"
            ),
        )
    return {"message": "If this email exists, a deletion link has been sent."}

@app.post("/api/auth/confirm-account-deletion")
async def confirm_account_deletion(body: AccountDeletionConfirmRequest):
    record = await db.account_deletions.find_one({"token": body.token, "used": False})
    if not record:
        raise HTTPException(400, "Invalid or expired deletion token")
    if record.get("expires_at") and record["expires_at"] < now_iso():
        raise HTTPException(400, "Invalid or expired deletion token")
    user_id = record["user_id"]
    await db.users.update_one(
        {"id": user_id},
        {
            "$set": {
                "deleted": True,
                "deleted_at": now_iso(),
                "email": f"deleted-{user_id}@deleted.local",
                "name": "Deleted user",
                "bio": None,
                "photo_url": None,
                "banned": True,
            },
            "$inc": {"token_version": 1},  # immediately invalidate all existing JWTs
        },
    )
    await db.account_deletions.update_one({"token": body.token}, {"$set": {"used": True, "used_at": now_iso()}})
    return {"message": "Account deleted."}

# ── GDPR / UK GDPR — Data Export ──────────────────────────────────────────────
@app.get("/api/auth/export-my-data")
async def export_my_data(request: Request, user: dict = Depends(get_current_user)):
    """
    GDPR Art. 20 / UK GDPR data portability.
    Returns all personal data held about the authenticated user as JSON.
    Rate-limited to 3 requests per day to prevent abuse.
    """
    await rate_limit(request, "data-export", 3, 86400, actor_id=user["id"])

    # Collect all data categories
    user_data = {k: v for k, v in user.items() if k not in {"_id", "password_hash"}}

    swipes = await db.swipes.find(
        {"user_id": user["id"]}, {"_id": 0}
    ).to_list(5000)

    matches_raw = await db.matches.find(
        {"users": user["id"]}, {"_id": 0}
    ).to_list(500)
    match_ids = [m["id"] for m in matches_raw]

    messages = await db.messages.find(
        {"match_id": {"$in": match_ids}, "sender_id": user["id"]}, {"_id": 0}
    ).to_list(10000)

    reports_filed = await db.reports.find(
        {"reporter_id": user["id"]}, {"_id": 0}
    ).to_list(500)

    security_events = await db.security_events.find(
        {"user_id": user["id"]}, {"_id": 0}
    ).to_list(1000)

    await audit_event("data_export", request=request, user_id=user["id"], severity="info")

    return {
        "exported_at": now_iso(),
        "data_controller": "Obi Dating Ltd",
        "gdpr_basis": "Art. 20 UK GDPR — Data Portability",
        "profile": user_data,
        "swipes": swipes,
        "matches": matches_raw,
        "messages_sent": messages,
        "reports_filed": reports_filed,
        "security_events": security_events,
    }


# ── Online Safety Act — Complaints & Appeals ───────────────────────────────────
class ComplaintRequest(BaseModel):
    complaint_type: str   # "moderation_decision" | "harmful_content" | "other"
    description: str
    related_user_id: Optional[str] = None
    related_content_id: Optional[str] = None

@app.post("/api/complaints")
async def submit_complaint(
    body: ComplaintRequest,
    request: Request,
    user: dict = Depends(get_current_user),
):
    """
    UK Online Safety Act s.20 / Ofcom guidance — user complaints mechanism.
    All complaints are stored, assigned a reference ID, and queued for review.
    Users receive a confirmation with their reference number.
    """
    await rate_limit(request, "complaints", 5, 3600, actor_id=user["id"])

    VALID_TYPES = {"moderation_decision", "harmful_content", "account_suspension", "data_handling", "other"}
    if body.complaint_type not in VALID_TYPES:
        raise HTTPException(400, f"complaint_type must be one of: {', '.join(VALID_TYPES)}")
    if len(body.description.strip()) < 20:
        raise HTTPException(400, "Please provide a more detailed description (at least 20 characters)")

    reference_id = "ASA-" + uuid.uuid4().hex[:8].upper()
    complaint = {
        "id": str(uuid.uuid4()),
        "reference_id": reference_id,
        "user_id": user["id"],
        "complaint_type": body.complaint_type,
        "description": body.description.strip(),
        "related_user_id": body.related_user_id,
        "related_content_id": body.related_content_id,
        "status": "received",          # received → under_review → resolved / escalated
        "resolution": None,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "resolved_at": None,
    }
    await db.complaints.insert_one(complaint)
    await metric_incr("complaints_received")
    await audit_event("complaint_submitted", request=request, user_id=user["id"],
                      severity="info", reference_id=reference_id, type=body.complaint_type)

    # Notify the user by email with their reference
    await send_email(
        to=user["email"],
        subject=f"Obi complaint received — reference {reference_id}",
        body_text=(
            f"Hi {user.get('name', 'there')},\n\n"
            f"We've received your complaint (reference: {reference_id}).\n\n"
            f"Type: {body.complaint_type}\n"
            f"Description: {body.description.strip()[:300]}\n\n"
            "We aim to respond within 7 working days in line with UK Online Safety Act obligations. "
            "If you are not satisfied with our response, you may escalate to Ofcom.\n\n"
            "— The Obi Trust & Safety Team"
        ),
    )

    return {
        "reference_id": reference_id,
        "status": "received",
        "message": (
            "Your complaint has been received and will be reviewed within 7 working days. "
            f"Your reference number is {reference_id}. A confirmation has been sent to your email."
        ),
    }


@app.get("/api/complaints")
async def get_my_complaints(user: dict = Depends(get_current_user)):
    """Let users track the status of their own complaints."""
    complaints = await db.complaints.find(
        {"user_id": user["id"]}, {"_id": 0, "id": 0}
    ).sort("created_at", -1).to_list(50)
    return {"complaints": complaints}


@app.post("/api/admin/complaints/{complaint_id}/resolve")
async def resolve_complaint(
    complaint_id: str,
    body: dict,
    request: Request,
    _: None = Depends(require_admin),
):
    """Admin: resolve a complaint with a decision and optional note."""
    resolution = (body.get("resolution") or "").strip()
    if not resolution:
        raise HTTPException(400, "resolution text is required")
    result = await db.complaints.find_one_and_update(
        {"id": complaint_id},
        {"$set": {
            "status": body.get("status", "resolved"),
            "resolution": resolution,
            "resolved_at": now_iso(),
            "updated_at": now_iso(),
        }},
        return_document=True,
    )
    if not result:
        raise HTTPException(404, "Complaint not found")
    # Email the user with the outcome
    user = await db.users.find_one({"id": result["user_id"]})
    if user:
        await send_email(
            to=user["email"],
            subject=f"Update on your Obi complaint {result['reference_id']}",
            body_text=(
                f"Hi {user.get('name', 'there')},\n\n"
                f"We've reviewed your complaint (reference: {result['reference_id']}).\n\n"
                f"Outcome: {resolution}\n\n"
                "If you are not satisfied with this outcome, you may escalate to Ofcom at https://www.ofcom.org.uk.\n\n"
                "— The Obi Trust & Safety Team"
            ),
        )
    return {"resolved": True, "complaint": {k: v for k, v in result.items() if k != "_id"}}


# ── Legal content endpoints (served in-app to avoid browser redirects) ─────────
@app.get("/api/legal/terms")
async def legal_terms():
    """
    Terms of Service — returned as structured JSON so the app can render them
    natively without opening a browser. Update version/content here as needed.
    Update `accepted_tos_version` in RegisterRequest to force re-acceptance.
    """
    return {
        "version": "1.0",
        "effective_date": "2026-05-01",
        "title": "Obi Dating — Terms of Service",
        "sections": [
            {
                "heading": "1. Eligibility",
                "body": (
                    "You must be at least 18 years old and legally able to enter a binding contract "
                    "in your jurisdiction to use Obi. By registering, you confirm you meet these requirements."
                ),
            },
            {
                "heading": "2. Your account",
                "body": (
                    "You are responsible for maintaining the confidentiality of your login credentials. "
                    "You agree to provide accurate, current, and complete information during registration "
                    "and to update it as needed. One account per person; shared or bot accounts are prohibited."
                ),
            },
            {
                "heading": "3. Acceptable use",
                "body": (
                    "You agree not to: post false information; harass, abuse, or harm other users; "
                    "use the service for commercial solicitation or scams; attempt to reverse-engineer the platform; "
                    "circumvent safety features; or upload content that is illegal, violent, or sexually explicit. "
                    "Violations may result in immediate account termination."
                ),
            },
            {
                "heading": "4. User-generated content",
                "body": (
                    "You retain ownership of content you post (photos, messages, bio). By posting, you grant "
                    "Obi a limited, non-exclusive licence to display that content to other users for the purpose "
                    "of operating the service. We do not sell your content to third parties."
                ),
            },
            {
                "heading": "5. Gold subscription & billing",
                "body": (
                    "Gold subscriptions are billed monthly via Stripe. You may cancel at any time; "
                    "cancellation takes effect at the end of the current billing period. "
                    "Refunds are handled in line with UK consumer law."
                ),
            },
            {
                "heading": "6. Moderation & safety",
                "body": (
                    "We moderate content to protect users from harm. Moderation decisions may be appealed "
                    "via the in-app complaints mechanism. Obi complies with the UK Online Safety Act 2023."
                ),
            },
            {
                "heading": "7. Limitation of liability",
                "body": (
                    "Obi is provided 'as is'. We are not liable for the conduct of other users. "
                    "Our liability is limited to the amount you paid us in the 12 months preceding a claim. "
                    "Nothing in these terms limits liability for fraud, personal injury, or death."
                ),
            },
            {
                "heading": "8. Governing law",
                "body": (
                    "These terms are governed by the laws of England and Wales. "
                    "Disputes will be resolved in the courts of England and Wales, "
                    "unless you are a consumer entitled to bring proceedings in your local court."
                ),
            },
            {
                "heading": "9. Changes",
                "body": (
                    "We may update these terms. We will notify you of material changes by email "
                    "or in-app notification at least 14 days before they take effect. "
                    "Continued use after the effective date constitutes acceptance."
                ),
            },
            {
                "heading": "10. Contact",
                "body": "For questions about these terms, contact legal@your-real-domain.com.",
            },
        ],
    }


@app.get("/api/legal/privacy")
async def legal_privacy():
    """
    Privacy Policy — GDPR / UK GDPR compliant, returned as structured JSON
    for in-app rendering. Update as needed; bump version when material changes are made.
    """
    return {
        "version": "1.0",
        "effective_date": "2026-05-01",
        "title": "Obi Dating — Privacy Policy",
        "data_controller": "Obi Dating Ltd, England & Wales",
        "contact_email": "privacy@your-real-domain.com",
        "sections": [
            {
                "heading": "1. What data we collect",
                "body": (
                    "We collect: (a) account data — name, email address, date of birth (hashed after age verification), "
                    "password (bcrypt-hashed); (b) profile data — age, gender, city, country, tribe, bio, photo, interests, languages; "
                    "(c) usage data — swipe actions, match history, messages (encrypted in transit); "
                    "(d) device data — push notification token, IP address (for security logs, retained 90 days); "
                    "(e) payment data — handled by Stripe; we store only your subscription status."
                ),
            },
            {
                "heading": "2. Why we use your data (legal basis)",
                "body": (
                    "Contract performance (Art. 6(1)(b)): to operate matching and messaging. "
                    "Legitimate interests (Art. 6(1)(f)): fraud prevention, security monitoring, service improvement. "
                    "Legal obligation (Art. 6(1)(c)): Online Safety Act compliance, responding to lawful requests. "
                    "Consent (Art. 6(1)(a)): push notifications (you may withdraw at any time in device settings)."
                ),
            },
            {
                "heading": "3. Who we share data with",
                "body": (
                    "We do not sell your personal data. We share limited data with: "
                    "Stripe (payment processing, their privacy policy applies); "
                    "AWS S3 / Cloudflare R2 (photo storage, data stays in EU/UK regions where configured); "
                    "Resend or your SMTP provider (email delivery); "
                    "Expo (push notification token delivery). "
                    "Law enforcement requests are handled under UK GDPR Art. 6(1)(c)."
                ),
            },
            {
                "heading": "4. How long we keep your data",
                "body": (
                    "Active account data: retained while your account is active. "
                    "Deleted accounts: profile data anonymised immediately; logs retained 90 days for fraud prevention. "
                    "Security event logs: 90 days (TTL index on database). "
                    "Email verification tokens: 24 hours (TTL index). "
                    "Messages: retained for the lifetime of the match; deleted when either user deletes their account."
                ),
            },
            {
                "heading": "5. Your rights",
                "body": (
                    "Under UK GDPR you have the right to: access your data (use 'Export my data' in Settings); "
                    "rectify inaccurate data (edit your profile); erase your data ('Delete account' in Settings); "
                    "data portability (JSON export via 'Export my data'); "
                    "object to processing for legitimate interests; "
                    "withdraw consent for push notifications (device Settings > Notifications). "
                    "To exercise any right, use the in-app features or contact privacy@your-real-domain.com."
                ),
            },
            {
                "heading": "6. Security",
                "body": (
                    "Passwords are bcrypt-hashed. Data is encrypted in transit (TLS). "
                    "Photos are stored in a private S3 bucket with signed URLs. "
                    "We run automated content moderation and fraud detection."
                ),
            },
            {
                "heading": "7. Cookies & tracking",
                "body": (
                    "The mobile app does not use cookies. We use anonymous analytics for product improvement. "
                    "No advertising tracking or third-party ad networks."
                ),
            },
            {
                "heading": "8. International transfers",
                "body": (
                    "We aim to keep data in the UK/EU. Where processors are based outside these regions "
                    "(e.g. Expo's push infrastructure), transfers are covered by Standard Contractual Clauses "
                    "or adequacy decisions."
                ),
            },
            {
                "heading": "9. Contact & complaints",
                "body": (
                    "Contact our Data Protection contact at privacy@your-real-domain.com. "
                    "You have the right to lodge a complaint with the ICO (ico.org.uk) "
                    "if you believe we have mishandled your personal data."
                ),
            },
        ],
    }


@app.get("/api/health")
async def health():
    result = {"status": "ok", "api": "ok", "mongo": "unknown", "redis": "unknown", "stripe_enabled": STRIPE_ENABLED, "ai_features": AI_FEATURES_ENABLED}
    try:
        await db.command("ping")
        result["mongo"] = "ok"
    except Exception as exc:
        result["mongo"] = f"error: {str(exc)[:120]}"
        result["status"] = "degraded"
    try:
        if redis_client:
            await _redis_run(redis_client.ping)
            result["redis"] = "ok"
        else:
            result["redis"] = "not_configured"
    except Exception as exc:
        result["redis"] = f"error: {str(exc)[:120]}"
    result["ready"] = result.get("mongo") == "ok"
    return result


