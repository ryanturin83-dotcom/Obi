# iOS TestFlight runbook

## Prerequisites

- Paid Apple Developer account.
- App Store Connect access.
- Expo/EAS account.
- Bundle identifier in `frontend/app.json` matches the App Store Connect app record.
- Production API URL is configured through EAS secrets or build env.

## Build

```bash
cd frontend
./scripts/testflight_build.sh
```

## Submit latest successful build

```bash
cd frontend
./scripts/testflight_submit_latest.sh
```

## Before external testers

- Privacy Policy URL is live.
- Terms URL is live.
- Support URL is live.
- Account deletion path is documented.
- Report/block flows are visible in the app.
- Backend is running with production secrets, MongoDB, Redis, alert webhook, and backups enabled.
