# Full runtime test plan

These checks require the real backend services: MongoDB, Redis, backend dependencies, and the mobile app running against that backend.

## Local backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export MONGO_URL=mongodb://localhost:27017
export REDIS_URL=redis://localhost:6379
export JWT_SECRET=$(python -c 'import secrets; print(secrets.token_hex(64))')
uvicorn server:app --host 0.0.0.0 --port 8000
```

In another terminal:

```bash
API_URL=http://localhost:8000 ./scripts/run_full_runtime_check.sh
```

## Manual app flow

Run the frontend:

```bash
cd frontend
npm install
EXPO_PUBLIC_API_URL=http://YOUR-LAN-IP:8000 npx expo start --tunnel
```

Then test on a device:

1. Register.
2. Login.
3. Complete onboarding.
4. Upload a normal JPEG/PNG.
5. Try an oversized/progressive/bad file and confirm rejection.
6. Open discover.
7. Send/report/block if matching data exists.
8. Logout.
9. Confirm the old token cannot call `/api/me`.

## Pass criteria

- `/api/health` says Mongo is `ok`.
- Smoke script passes.
- No uncaught backend exceptions during the manual flow.
- Security logs record auth failures, rate limits, and upload rejections without leaking passwords/tokens.
