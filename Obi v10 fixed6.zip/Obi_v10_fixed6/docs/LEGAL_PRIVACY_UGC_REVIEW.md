# Legal/privacy review for user-generated content

This is not legal advice. Have a qualified lawyer review before broad launch.

## Required public docs
- Terms of Service covering user conduct, prohibited content, account termination, paid features, and dispute process.
- Privacy Policy covering profile data, location/city, photos, messages, moderation/audit logs, analytics, retention, deletion, and subprocessors.
- Community Guidelines covering harassment, hate, sexual content rules, impersonation, spam, scams, and report/block behavior.
- Safety page explaining reporting, blocking, moderation review, and emergency limitations.

## Product requirements
- In-app reporting and blocking must be easy to reach.
- Users should know uploaded photos/messages may be scanned or reviewed for safety.
- Keep moderation/audit data only as long as needed and define retention periods.
- Document appeal/review path for bans, shadowbans, rejected photos, and removed messages.
- Age policy must match your jurisdictional and app-store requirements.

## Launch recommendation
Before public launch, publish the docs above, add links in onboarding/settings, and verify consent/acceptance is stored with timestamp and policy version.
