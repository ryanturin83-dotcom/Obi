# Horizontal Scaling Plan

- Run multiple backend containers behind a load balancer.
- Keep API stateless with JWT auth.
- Store app data in MongoDB Atlas.
- Use managed Redis for cache/rate limits.
- Use `/api/health` for readiness checks.
- Store media in S3/R2 + CDN, not MongoDB.
- For multi-instance WebSocket fanout, add a Redis Pub/Sub listener or managed realtime service.
