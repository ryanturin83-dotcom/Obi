# UX Polish Included

- Warm dark/gold brand theme.
- Clear auth flow.
- 8-character password hint.
- Fast onboarding test flow.
- Discover card with compatibility badge.
- Clear empty states.
- Like/pass actions.
- Matches list.
- API errors shown as friendly alerts.
