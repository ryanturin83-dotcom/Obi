# App Store privacy and moderation readiness

Use this before TestFlight external testing and before App Review.

## Required App Store privacy answers

Map your App Store Connect privacy labels to the actual production behavior before submission.

Likely collected data categories:

- Contact info: email address, name.
- User content: profile photos, bio, messages, reports.
- Identifiers: internal user id, push token if enabled.
- Location: approximate or precise location only when the user enables nearby matching.
- Diagnostics: crash logs, API/security logs if tied to a user id.

Do not claim data is not linked to the user if logs, moderation queues, reports, or admin tools preserve user ids.

## In-app safety requirements

Before public App Review, verify:

- Report user is available from every profile and conversation surface.
- Block user is available from every profile and conversation surface.
- Account deletion is available without contacting support.
- Terms of Service and Privacy Policy are reachable from onboarding/settings.
- UGC moderation policy explains what content is banned.
- Photos/messages can be removed by moderators.
- Banned/shadowbanned users cannot continue harassing others.

## Moderator operating procedure

Daily during launch week:

1. Review `/api/admin/moderation/queue`.
2. Prioritize photos, messages, and repeated reports.
3. Resolve false positives so good users are not trapped.
4. Ban clear abuse, threats, sexual exploitation, impersonation, spam, or harassment.
5. Export weekly counts: reports received, photos rejected, users banned, appeal reversals.

## Required public documents

Create and host:

- Privacy Policy
- Terms of Service
- Community Guidelines
- Safety / Reporting page
- Account Deletion page

Update `APP_BASE_URL`, app links, and App Store metadata to point to those hosted pages.
