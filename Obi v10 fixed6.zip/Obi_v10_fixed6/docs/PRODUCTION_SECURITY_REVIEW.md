# Production security review checklist

## Infrastructure
- Enforce HTTPS/TLS at the load balancer and origin.
- Restrict CORS to production app origins only.
- Store `JWT_SECRET`, DB URLs, S3 keys, Stripe keys, moderation keys, and alert secrets in a secrets manager.
- Rotate any key that was ever used in development or shared in chat/logs.
- Lock MongoDB and Redis to private networking; no public ingress.
- Enable storage bucket private write access and serve images through a controlled public base URL/CDN.
- Enable WAF/bot controls in front of `/api/*`.

## App security
- Confirm every write endpoint has per-user and IP rate limits.
- Confirm WebSocket auth times out and rejects re-auth attempts.
- Confirm all auth failure, rate-limit, moderation, upload rejection, and admin actions are written to `security_events`.
- Confirm admin endpoints require `X-Admin-Key` from secrets manager and are blocked at the network layer where possible.

## Data protection
- Verify backups are encrypted, retained, and restore-tested.
- Verify account deletion removes or anonymizes personal data according to your privacy policy.
- Verify logs never include JWTs, passwords, authorization headers, or raw private messages beyond moderation/audit needs.

## Go/no-go
Do not launch publicly until a clean staging deploy passes: smoke tests, load test, backup restore drill, moderation provider test, and alert delivery test.
