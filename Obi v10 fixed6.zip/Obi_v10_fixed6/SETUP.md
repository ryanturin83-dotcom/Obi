# Obi v10 — First-time setup checklist

Work through these in order. Items marked **[BLOCKING]** must be done before any build.

---

## 1. EAS project ID [BLOCKING]

```bash
cd frontend
npm install -g eas-cli   # if not already installed
eas login
eas build:configure      # writes real UUID into app.json
git add app.json && git commit -m "chore: set EAS project ID"
```

---

## 2. Secrets [BLOCKING]

```bash
# Backend
cp backend/.env.example backend/.env
# Open backend/.env and replace every REPLACE_* value
# Generate secrets:
python -c "import secrets; print(secrets.token_hex(64))"  # JWT_SECRET
python -c "import secrets; print(secrets.token_hex(32))"  # ADMIN_API_KEY

# Frontend
cp frontend/.env.example frontend/.env
# Set EXPO_PUBLIC_BACKEND_URL=https://your-api-domain.com/api
```

---

## 3. Lockfile [BLOCKING]

```bash
cd frontend
npm install              # generates package-lock.json
git add package-lock.json && git commit -m "chore: add lockfile"
```

---

## 4. Domain — deep links

Replace `REPLACE_WITH_YOUR_DOMAIN` in:
- `frontend/app.json` → `ios.associatedDomains` and `android.intentFilters`
- `backend/static/.well-known/apple-app-site-association` → `appID`
- `backend/static/.well-known/assetlinks.json` → `sha256_cert_fingerprints`

Serve both files over HTTPS with `Content-Type: application/json` and no redirect.
Apple fetches the AASA file on first app install — it must be live before TestFlight.

Get your Android signing cert fingerprint:
```bash
keytool -list -v -keystore your-release.keystore | grep SHA256
```

---

## 5. Apple Team ID

Find it at [developer.apple.com/account](https://developer.apple.com/account) → Membership.
Replace `REPLACE_WITH_APPLE_TEAM_ID` in `backend/static/.well-known/apple-app-site-association`.

---

## 6. Legal sign-off

Before public launch, a qualified UK/EU data protection solicitor must review:
- Terms of Service (`/api/legal/terms`)
- Privacy Policy (`/api/legal/privacy`)
- Community Guidelines (`/api/legal/community-guidelines`)
- Data Processing Agreements with: MongoDB Atlas, Resend, Stripe, your S3 provider, moderation provider

The privacy policy URL is required by both Apple App Store and Google Play.

---

## 7. Verify everything

```bash
cd backend && python scripts/runtime_smoke_test.py
cd frontend && npm run test:smoke
cd frontend && npm run doctor
```
