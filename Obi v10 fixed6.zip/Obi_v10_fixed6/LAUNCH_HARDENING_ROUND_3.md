# Launch Hardening Round 3: Abuse Resistance, Observability, Background Moderation

## Abuse resistance
- Added a global write throttle for all POST/PUT/PATCH/DELETE routes, so abuse cannot simply move from one endpoint to another.
- Added message content flagging for URLs, overly long text, and configurable blocked patterns via `BANNED_CONTENT_PATTERNS`.
- Added moderation jobs for flagged messages, reports, and uploaded photos.
- Added report aggregation on targets with `open_report_count`.
- Added optional auto-shadowban when unresolved reports exceed `AUTO_SHADOWBAN_REPORT_THRESHOLD`.
- Excluded shadowbanned users from discovery, compatibility lookups, and WebSocket auth.

## Observability
- Added persisted `security_events` audit records for auth failures, rate-limit hits, uploads sent to moderation, reports, and moderation decisions.
- Added Redis-backed counters for auth failures, rate-limit hits, WebSocket rate-limit hits, upload rejections, and queued moderation jobs.
- Added admin endpoint `GET /api/admin/metrics`, protected by `X-Admin-Key`, to view counters, recent security events, flagged messages, and moderation queue depth.
- Added structured security audit logs suitable for ingestion by a log platform.

## Background moderation
- Added `moderation_jobs` collection workflow.
- Added `GET /api/admin/moderation/jobs` to review queued jobs.
- Added `POST /api/admin/moderation/jobs/{job_id}/resolve` to approve/reject content, ban users, or shadowban users.
- Uploaded photos are now marked `photo_moderation_status=pending` and queued for moderation after malware scan and re-encoding.
- Flagged messages are queued for review and can be rejected by moderators.

## New environment variables
- `ADMIN_API_KEY`: required for admin moderation/metrics endpoints.
- `GLOBAL_WRITE_LIMIT`: default `240` writes per IP per 5 minutes.
- `BANNED_CONTENT_PATTERNS`: comma-separated patterns to reject in messages.
- `AUTO_SHADOWBAN_REPORT_THRESHOLD`: default `5` unresolved reports.
- `MODERATION_WORKER_ENABLED`: reserved for external worker deployment.

## Validation
- `python3 -m py_compile backend/server.py` passes.
