# Launch hardening round 4

## External moderation provider / stronger scanning
- Added `MODERATION_PROVIDER_URL`, `MODERATION_PROVIDER_API_KEY`, timeout, and fail-open/fail-closed config.
- Added `external_moderation()` provider hook for messages and photos.
- Message sends now combine local flags with provider flags and block provider-rejected content.
- Photo uploads now submit the stored image URL to the moderation provider and mark flagged images higher priority.

## Real alerting
- Added `ALERT_WEBHOOK_URL`, optional HMAC signing secret, and severity threshold.
- `audit_event()` now sends high-severity events to the configured webhook.
- Added `deploy/alerts.example.json` for alert policy thresholds.

## Load testing
- Added `scripts/load_test_k6.js` for API health, authenticated `/api/me`, and WebSocket auth path testing.
- Example: `BASE_URL=https://api.example.com TEST_JWT=... k6 run scripts/load_test_k6.js`.

## Backup/restore testing
- Added `scripts/backup_restore_check.sh` to dump MongoDB and restore into a drill database.
- Requires `mongodump`, `mongorestore`, and `mongosh` installed in the execution environment.

## Security review on deployed infrastructure
- Added `docs/PRODUCTION_SECURITY_REVIEW.md` with infra, secrets, CORS, WAF, DB/Redis, storage, admin, and logging checks.

## Legal/privacy review for UGC
- Added `docs/LEGAL_PRIVACY_UGC_REVIEW.md` covering Terms, Privacy Policy, Community Guidelines, moderation disclosure, retention, appeals, and age policy.
