# Obi v10 — Polished UX + Horizontally Scalable Backend

## Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn server:app --reload --host 0.0.0.0 --port 8001
python test_core_flow.py http://localhost:8001
```

## Frontend

```bash
cd frontend
npm install
cp .env.example .env
# edit EXPO_PUBLIC_BACKEND_URL to your LAN IP, e.g. http://192.168.1.10:8001/api
npx expo start --clear
```

## Docker

```bash
cd deploy
docker compose up --build
```
