# Bug and crash cleanup report

This package was checked and cleaned after the feature-restored frontend pass.

## Fixed

- Added a React error boundary so unexpected UI render errors show a safe recovery screen instead of a blank/crashed app.
- Added frontend API request timeouts with clear user-facing timeout errors so network calls do not hang indefinitely.
- Added a longer timeout for photo uploads while still preventing indefinite upload hangs.
- Hardened frontend list handling so unexpected backend response shapes do not crash `FlatList` screens.
- De-duplicated incoming WebSocket messages by message id to avoid repeated messages after reconnects.
- Made account deletion clear local app state and close the WebSocket, not just clear the token.
- Fixed the backend core-flow test fixture so the second test user passes the real onboarding rule requiring at least 3 interests.
- Hardened the Redis WebSocket pub/sub listener so Redis outages retry with backoff instead of silently crashing or spinning.

## Checks run

- `node --check frontend/App.js`
- `node --check frontend/src/api.js`
- `node frontend/scripts/smoke-config.js`
- `python3 -S -m py_compile backend/server.py backend/test_core_flow.py scripts/runtime_smoke_test.py`
- JSON validation for app/deploy config files
- `bash -n` for shell scripts

## Not run here

Full live runtime testing requires the real dependency install plus MongoDB, Redis, storage credentials, backend environment variables, and iOS/EAS credentials.
