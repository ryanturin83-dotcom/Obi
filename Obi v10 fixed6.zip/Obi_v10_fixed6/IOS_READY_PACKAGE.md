# iOS Ready Package

This package is prepared for an Expo/EAS iOS build.

## Required before App Store/TestFlight build

1. Replace `extra.eas.projectId` in `frontend/app.json` with your real EAS project id.
2. Set `EXPO_PUBLIC_BACKEND_URL` to your production HTTPS API URL, for example `https://api.yourdomain.com/api`.
3. Replace generated placeholder assets in `frontend/assets/` with final branded icon/splash artwork before store submission.
4. Run a backend with MongoDB, Redis, S3/R2 storage, and production env vars.

## Build commands

```bash
cd frontend
npm install
npx expo-doctor
npx eas build --platform ios --profile preview
npx eas build --platform ios --profile production
```

## Backend smoke test

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001
python test_core_flow.py http://localhost:8001
```
