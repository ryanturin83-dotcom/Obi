# Launch hardening round 2

Implemented against the patched Obi v9 backend.

## 1. Global rate limiting
Added Redis-backed user+IP rate limits to key write/abuse endpoints, not just reports:

- `/api/profile/onboarding`
- `/api/profile/filters`
- `/api/swipe`
- `/api/messages`
- `/api/report`
- `/api/block`
- `/api/profile/photo`
- `/api/profile/photo/upload-url`
- `/api/profile/photo/confirm`
- `/api/auth/logout`
- `/api/auth/change-password`
- `/api/boost`
- `/api/stripe/create-checkout-session`
- `/api/push/register`

Rate-limit hits now emit structured `security_event=rate_limit_hit` logs.

## 2. WebSocket edge cases
- WebSocket now requires the first message to be `{ "type": "auth", "token": "..." }` within 5 seconds.
- Missing/invalid/expired/revoked tokens close the socket with policy violation.
- Re-authentication attempts after connection are rejected and logged.
- Incoming WebSocket event frames are rate limited per authenticated user.
- Fixed a double-accept bug by ensuring `ConnectionManager.connect()` does not call `accept()` after the endpoint already accepted the socket.

## 3. Upload limits and image hardening
- Hard max upload size defaults to 8 MB via `MAX_PHOTO_BYTES`.
- Hard max resolution defaults to 12 megapixels via `MAX_PHOTO_PIXELS`.
- File reads are capped at `MAX_PHOTO_BYTES + 1` to avoid reading arbitrarily large uploads into memory.
- Progressive JPEGs are rejected.
- Images are still decoded and re-encoded to strip metadata/trailing payloads/polyglot content.
- Unsupported file types, oversized files, oversize dimensions, too-small photos, progressive JPEGs, and decode/re-encode failures are logged.

## 4. Observability
Added structured security logs for:

- Auth failures: missing, invalid, expired, revoked tokens
- WebSocket auth failures and re-auth attempts
- Rate-limit hits
- Upload rejections
- Scanner failures/flags still log as before

These logs avoid printing secrets/tokens/passwords.
